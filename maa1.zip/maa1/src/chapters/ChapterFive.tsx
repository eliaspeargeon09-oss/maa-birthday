import React, { useEffect, useRef } from "react";
import { birthdayContent } from "../data/birthdayContent";
import { LoveCards } from "../components/LoveCards";
import { Sparkles } from "lucide-react";
import anime from "animejs";

export const ChapterFive: React.FC = () => {
  const { chapterFive } = birthdayContent;
  const headerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (headerRef.current) {
      anime({
        targets: headerRef.current,
        opacity: [0, 1],
        translateY: [20, 0],
        duration: 850,
        easing: "easeOutCubic"
      });
    }
  }, []);

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 sm:py-12 text-[#F4FAFF] flex flex-col items-center select-none relative z-10">
      {/* Chapter Header */}
      <div ref={headerRef} className="text-center mb-8 sm:mb-12 max-w-2xl opacity-0">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#123B70]/60 border border-[#55B7E8]/30 text-[#55B7E8] text-xs font-sans uppercase tracking-widest mb-3 backdrop-blur-md">
          <Sparkles className="w-3.5 h-3.5 text-[#55B7E8]" />
          <span>Affirmations of Gratitude</span>
        </div>
        <h2 className="font-serif text-3xl sm:text-5xl font-semibold text-[#F4FAFF] tracking-wide mb-2 drop-shadow-md">
          {chapterFive.headline}
        </h2>
        <p className="font-serif italic text-base sm:text-lg text-[#D9F2FF]/80">
          {chapterFive.subheading}
        </p>
      </div>

      {/* 6 Interactive Cards Component */}
      <LoveCards />
    </div>
  );
};
