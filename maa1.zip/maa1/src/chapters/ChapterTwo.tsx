import React, { useEffect, useRef } from "react";
import { birthdayContent } from "../data/birthdayContent";
import { Heart, ArrowRight } from "lucide-react";
import anime from "animejs";

interface ChapterTwoProps {
  onContinue: () => void;
}

export const ChapterTwo: React.FC<ChapterTwoProps> = ({ onContinue }) => {
  const { chapterTwo } = birthdayContent;
  const containerRef = useRef<HTMLDivElement | null>(null);
  const headlineRef = useRef<HTMLHeadingElement | null>(null);
  const paragraphsRef = useRef<HTMLDivElement | null>(null);
  const revealRef = useRef<HTMLDivElement | null>(null);
  const buttonRef = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    const tl = anime.timeline({
      easing: "easeOutCubic"
    });

    if (headlineRef.current) {
      tl.add({
        targets: headlineRef.current,
        opacity: [0, 1],
        translateY: [25, 0],
        duration: 900
      });
    }

    if (paragraphsRef.current) {
      const items = paragraphsRef.current.querySelectorAll(".story-paragraph");
      tl.add({
        targets: items,
        opacity: [0, 1],
        translateY: [20, 0],
        delay: anime.stagger(280),
        duration: 800
      });
    }

    if (revealRef.current) {
      tl.add({
        targets: revealRef.current,
        opacity: [0, 1],
        scale: [0.95, 1],
        duration: 900,
        offset: "+=150"
      });
    }

    if (buttonRef.current) {
      tl.add({
        targets: buttonRef.current,
        opacity: [0, 1],
        translateY: [15, 0],
        duration: 700,
        offset: "+=100"
      });
    }

    return () => {
      tl.pause();
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className="min-h-[80vh] flex flex-col items-center justify-center text-center px-4 py-8 max-w-4xl mx-auto select-none relative z-10"
    >
      {/* Decorative top sapphire badge */}
      <div className="w-12 h-12 rounded-full border border-[#55B7E8]/40 bg-[#123B70]/40 backdrop-blur-md flex items-center justify-center text-[#55B7E8] shadow-[0_0_20px_rgba(85,183,232,0.3)] mb-6 animate-float-gentle">
        <Heart className="w-5 h-5 text-[#55B7E8] fill-[#55B7E8]/20" />
      </div>

      {/* Main Headline */}
      <h2
        ref={headlineRef}
        className="font-serif italic text-3xl sm:text-4xl md:text-5xl text-[#F4FAFF] font-semibold tracking-wide drop-shadow-md opacity-0 mb-8 sm:mb-12"
      >
        "{chapterTwo.headline}"
      </h2>

      {/* Editorial Glass Container */}
      <div className="w-full glass-water-card rounded-2xl sm:rounded-3xl p-6 sm:p-10 md:p-12 border border-[#55B7E8]/25 shadow-2xl relative overflow-hidden text-left sm:text-center">
        {/* Soft atmospheric gradient sheen */}
        <div
          className="absolute -top-24 -left-24 w-72 h-72 rounded-full bg-[#55B7E8]/10 blur-3xl pointer-events-none"
          aria-hidden="true"
        />

        {/* Narrative Paragraphs */}
        <div
          ref={paragraphsRef}
          className="space-y-4 sm:space-y-5 text-base sm:text-xl font-serif leading-relaxed sm:leading-loose text-[#D9F2FF]/90"
        >
          {chapterTwo.paragraphs.map((p, idx) => (
            <p key={idx} className="story-paragraph opacity-0">
              {p}
            </p>
          ))}
        </div>

        {/* Final Emotional Climax Reveal */}
        <div
          ref={revealRef}
          className="mt-8 sm:mt-10 pt-6 sm:pt-8 border-t border-[#55B7E8]/20 text-center opacity-0"
        >
          <span className="font-serif italic text-2xl sm:text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#55B7E8] via-[#F4FAFF] to-[#55B7E8] drop-shadow-[0_4px_25px_rgba(85,183,232,0.5)]">
            {chapterTwo.finalReveal}
          </span>
        </div>
      </div>

      {/* Continue Button */}
      <div className="mt-10 sm:mt-12">
        <button
          ref={buttonRef}
          type="button"
          onClick={onContinue}
          className="group inline-flex items-center gap-3 px-8 py-3.5 rounded-full bg-gradient-to-r from-[#1769AA] via-[#55B7E8] to-[#1769AA] text-[#071A33] font-semibold text-sm sm:text-base tracking-widest uppercase shadow-[0_10px_25px_rgba(85,183,232,0.35)] hover:shadow-[0_15px_35px_rgba(85,183,232,0.6)] hover:scale-105 active:scale-95 transition-all duration-300 cursor-pointer opacity-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#55B7E8]"
        >
          <span>Explore Memories</span>
          <ArrowRight className="w-4 h-4 text-[#071A33] group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </div>
  );
};
