import React, { useEffect, useRef } from "react";
import { LetterEnvelope } from "../components/LetterEnvelope";
import { Mail } from "lucide-react";
import anime from "animejs";

export const ChapterFour: React.FC = () => {
  const headerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (headerRef.current) {
      anime({
        targets: headerRef.current,
        opacity: [0, 1],
        translateY: [20, 0],
        duration: 850,
        easing: "easeOutCubic"
      });
    }
  }, []);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 sm:py-12 text-[#F4FAFF] flex flex-col items-center select-none relative z-10">
      {/* Chapter Subtitle Header */}
      <div ref={headerRef} className="text-center mb-8 sm:mb-12 opacity-0">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#123B70]/60 border border-[#55B7E8]/30 text-[#55B7E8] text-xs font-sans uppercase tracking-widest mb-3 backdrop-blur-md">
          <Mail className="w-3.5 h-3.5 text-[#55B7E8]" />
          <span>An Intimate Message</span>
        </div>
        <h2 className="font-serif text-3xl sm:text-5xl font-semibold text-[#F4FAFF] tracking-wide mb-2 drop-shadow-md">
          A Letter for Maa
        </h2>
        <p className="font-serif italic text-base sm:text-lg text-[#D9F2FF]/80">
          Words from the deepest corners of the heart
        </p>
      </div>

      {/* Interactive Envelope and Parchment */}
      <LetterEnvelope />
    </div>
  );
};
