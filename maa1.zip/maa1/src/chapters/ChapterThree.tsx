import React, { useEffect, useRef } from "react";
import { birthdayContent } from "../data/birthdayContent";
import { MemoryGallery } from "../components/MemoryGallery";
import { Camera } from "lucide-react";
import anime from "animejs";

export const ChapterThree: React.FC = () => {
  const { chapterThree } = birthdayContent;
  const headerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (headerRef.current) {
      anime({
        targets: headerRef.current,
        opacity: [0, 1],
        translateY: [20, 0],
        duration: 900,
        easing: "easeOutCubic"
      });
    }
  }, []);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-10 text-[#F4FAFF] flex flex-col items-center select-none relative z-10">
      {/* Chapter Header */}
      <div ref={headerRef} className="text-center mb-10 sm:mb-14 max-w-2xl opacity-0">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#123B70]/60 border border-[#55B7E8]/30 text-[#55B7E8] text-xs font-sans uppercase tracking-widest mb-3 backdrop-blur-md">
          <Camera className="w-3.5 h-3.5 text-[#55B7E8]" />
          <span>Keepsake Album</span>
        </div>
        <h2 className="font-serif text-3xl sm:text-5xl font-semibold text-[#F4FAFF] tracking-wide mb-3 drop-shadow-md">
          {chapterThree.headline}
        </h2>
        <p className="font-serif italic text-base sm:text-xl text-[#D9F2FF]/80">
          {chapterThree.subheading}
        </p>
      </div>

      {/* Interactive Floating Gallery */}
      <MemoryGallery />
    </div>
  );
};
