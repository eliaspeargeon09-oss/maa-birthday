import React, { useState, useEffect, useRef } from "react";
import { birthdayContent } from "../data/birthdayContent";
import { Sparkles, Waves } from "lucide-react";
import { triggerWaterRipple } from "../components/WaterCanvas";
import anime from "animejs";

interface ChapterOneProps {
  onBegin: () => void;
}

export const ChapterOne: React.FC<ChapterOneProps> = ({ onBegin }) => {
  const { chapterOne } = birthdayContent;
  // Phase 1: Intro lines 0, 1, 2
  // Phase 2: Fade intro lines out, reveal "MAA", subtext, and button
  const [phase, setPhase] = useState<"intro" | "title">("intro");
  const [lineIndex, setLineIndex] = useState<number>(0);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const titleBoxRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    // Reveal lines with smooth pacing
    const t1 = setTimeout(() => setLineIndex(1), 2200);
    const t2 = setTimeout(() => setLineIndex(2), 4600);
    const t3 = setTimeout(() => {
      // Transition from intro lines to "MAA" title
      setPhase("title");
    }, 7400);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, []);

  // When phase switches to 'title', trigger Anime.js reveal
  useEffect(() => {
    if (phase === "title" && titleBoxRef.current) {
      anime({
        targets: titleBoxRef.current,
        opacity: [0, 1],
        translateY: [30, 0],
        scale: [0.95, 1],
        duration: 1400,
        easing: "easeOutCubic"
      });
    }
  }, [phase]);

  const handleEnterWorld = (e: React.MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    // Trigger expanding ripple outward from the button
    triggerWaterRipple(centerX, centerY, 1.4);

    if (containerRef.current) {
      anime({
        targets: containerRef.current,
        opacity: [1, 0],
        scale: [1, 1.05],
        duration: 600,
        easing: "easeInOutQuad",
        complete: () => {
          onBegin();
        }
      });
    } else {
      onBegin();
    }
  };

  return (
    <div
      ref={containerRef}
      className="min-h-[82vh] flex flex-col items-center justify-center text-center px-4 py-8 max-w-4xl mx-auto select-none relative z-10"
    >
      {/* Soft atmospheric water glow */}
      <div
        className="w-96 h-96 rounded-full bg-gradient-to-r from-[#1769AA]/30 via-[#55B7E8]/20 to-[#123B70]/30 blur-3xl absolute pointer-events-none -z-10 animate-water-glow"
        aria-hidden="true"
      />

      {/* PHASE 1: Atmospheric introductory lines */}
      {phase === "intro" && (
        <div className="space-y-6 sm:space-y-8 min-h-[260px] flex flex-col justify-center">
          {chapterOne.lines.map((line, idx) => (
            <p
              key={idx}
              className={`font-serif tracking-wide transition-all duration-1000 ${
                idx <= lineIndex
                  ? "opacity-100 translate-y-0 text-xl sm:text-3xl md:text-4xl text-[#F4FAFF]/95"
                  : "opacity-0 translate-y-4 pointer-events-none text-xl sm:text-3xl"
              }`}
              style={{
                textShadow: "0 4px 20px rgba(7, 26, 51, 0.8), 0 0 15px rgba(85, 183, 232, 0.3)"
              }}
            >
              {line}
            </p>
          ))}

          {/* Skip intro button if user wants to proceed faster */}
          <button
            type="button"
            onClick={() => setPhase("title")}
            className="text-xs uppercase tracking-widest text-[#B8D8EA]/60 hover:text-[#F4FAFF] transition-colors mt-6 cursor-pointer"
          >
            Skip to World →
          </button>
        </div>
      )}

      {/* PHASE 2: Main "MAA" Reveal, Subtitle & Interactive Button */}
      {phase === "title" && (
        <div ref={titleBoxRef} className="flex flex-col items-center opacity-0">
          {/* Subtle water ripples icon badge */}
          <div className="w-14 h-14 rounded-full border border-[#55B7E8]/40 bg-[#123B70]/40 backdrop-blur-md flex items-center justify-center text-[#55B7E8] shadow-[0_0_25px_rgba(85,183,232,0.3)] mb-6 animate-float-gentle">
            <Waves className="w-6 h-6 animate-pulse" />
          </div>

          {/* "MAA" with liquid reflection effect */}
          <h1
            className="font-serif text-7xl sm:text-8xl md:text-9xl font-bold tracking-widest text-transparent bg-clip-text bg-gradient-to-b from-[#F4FAFF] via-[#D9F2FF] to-[#55B7E8] drop-shadow-[0_10px_35px_rgba(85,183,232,0.4)] select-none"
            style={{
              textShadow: "0 0 40px rgba(85, 183, 232, 0.45)"
            }}
          >
            {chapterOne.highlightWord}
          </h1>

          {/* Subtitle */}
          <p className="font-serif italic text-lg sm:text-2xl text-[#D9F2FF]/90 mt-4 tracking-wide max-w-xl">
            {chapterOne.subWord}
          </p>

          {/* Primary Action Button */}
          <div className="mt-10 sm:mt-12 flex flex-col items-center">
            <button
              type="button"
              onClick={handleEnterWorld}
              className="group relative inline-flex items-center gap-3 px-9 py-4 rounded-full bg-gradient-to-r from-[#1769AA] via-[#55B7E8] to-[#1769AA] text-[#071A33] font-semibold text-sm sm:text-base tracking-widest uppercase shadow-[0_10px_30px_rgba(85,183,232,0.4)] hover:shadow-[0_15px_45px_rgba(85,183,232,0.7)] hover:scale-105 active:scale-95 transition-all duration-300 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#55B7E8]"
            >
              <Sparkles className="w-4 h-4 text-[#071A33] group-hover:rotate-12 transition-transform" />
              <span>{chapterOne.buttonText}</span>
            </button>

            {/* Hint suggesting water interaction */}
            <p className="font-sans text-xs sm:text-sm text-[#B8D8EA]/70 mt-5 tracking-wider flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#55B7E8] animate-ping inline-block" />
              {chapterOne.instruction}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
