import React, { useEffect, useRef } from "react";
import { birthdayContent } from "../data/birthdayContent";
import { BirthdayCake } from "../components/BirthdayCake";
import anime from "animejs";

interface ChapterSevenProps {
  onWishCompleted: () => void;
}

export const ChapterSeven: React.FC<ChapterSevenProps> = ({ onWishCompleted }) => {
  const { chapterSeven } = birthdayContent;
  const headerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (headerRef.current) {
      anime({
        targets: headerRef.current,
        opacity: [0, 1],
        translateY: [20, 0],
        duration: 850,
        easing: "easeOutCubic"
      });
    }
  }, []);

  return (
    <div className="max-w-3xl mx-auto px-4 py-8 sm:py-12 text-[#F4FAFF] flex flex-col items-center text-center select-none relative z-10">
      {/* Chapter Subtitle Header */}
      <div ref={headerRef} className="mb-4 opacity-0">
        <span className="font-sans uppercase text-[11px] tracking-widest text-[#55B7E8] font-semibold">
          Anticipation
        </span>
        <h2 className="font-serif text-3xl sm:text-5xl font-semibold text-[#F4FAFF] mt-1 mb-2 tracking-wide drop-shadow-md">
          {chapterSeven.headline}
        </h2>
        <p className="font-serif italic text-base sm:text-xl text-[#D9F2FF]/85">
          {chapterSeven.supportingText}
        </p>
      </div>

      {/* Interactive Birthday Cake with Countdown */}
      <BirthdayCake onWishMade={onWishCompleted} />
    </div>
  );
};
