/**
 * Audio configuration for Maa's Birthday experience.
 * 
 * To add custom background music, drop an audio file into:
 * /public/audio/birthday-background.mp3
 */

export const AUDIO_CONFIG = {
  src: "/audio/birthday-background.mp3",
  title: "A Gentle Melody for Maa",
  defaultVolume: 0.65
};
