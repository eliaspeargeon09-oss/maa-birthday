/**
 * Centralized content repository for MAA — An Immersive Cinematic Birthday Experience.
 * Tailored for deep blue liquid cinema aesthetic.
 */

export const birthdayContent = {
  // Chapter 1: The Water World
  chapterOne: {
    lines: [
      "Some gifts cannot be wrapped.",
      "Some stories cannot be told in a single moment.",
      "But some people deserve an entire world."
    ],
    highlightWord: "MAA",
    subWord: "This little world was created just for you.",
    buttonText: "ENTER YOUR WORLD",
    instruction: "Touch or move across the water surface to feel the ripples."
  },

  // Chapter 2: A Story Written in Love
  chapterTwo: {
    headline: "Every beautiful story begins somewhere.",
    paragraphs: [
      "Some people change our lives without asking for recognition.",
      "They care in a thousand little ways.",
      "They give when they are tired.",
      "They encourage us when we doubt ourselves.",
      "They make ordinary moments feel precious.",
      "They turn a house into a home and a family into something beautiful.",
      "Sometimes, in the middle of our busy lives, we forget to tell them how much they mean to us.",
      "Today, we want to pause.",
      "To celebrate.",
      "To remember.",
      "And to say something that can never be said too many times."
    ],
    finalReveal: "Maa, you are deeply loved."
  },

  // Chapter 3: Memories That Live Forever
  chapterThree: {
    headline: "Every photograph holds a little piece of our story.",
    subheading: "Floating memories above the calm, reflective water"
  },

  // Chapter 4: A Letter for Maa
  chapterFour: {
    envelopeTitle: "For Maa, with all my love.",
    openButton: "OPEN YOUR LETTER",
    letterSalutation: "Maa,",
    paragraphs: [
      "There are so many things I want to tell you, and sometimes words do not seem enough.",
      "Life moves quickly. Days become busy, and we sometimes forget to express the love we carry in our hearts.",
      "But today, I want you to know something.",
      "You are not loved only because of what you do for us.",
      "You are loved for who you are.",
      "For your presence.",
      "For your heart.",
      "For the little things that make you uniquely you.",
      "For the memories we share and the moments that are still waiting for us.",
      "I hope this new year of your life brings you peace when you need it, strength when life feels difficult, laughter in unexpected moments, and beautiful reasons to smile.",
      "And I hope you never forget how precious you are to us.",
      "Happy Birthday, Maa.",
      "With all my love."
    ],
    signature: "With love, always."
  },

  // Chapter 5: Six Reasons You Are Special
  chapterFive: {
    headline: "Six little reminders of why you are so special.",
    subheading: "Tap any card to reveal what makes you irreplaceable",
    cards: [
      {
        id: "heart",
        number: "01",
        title: "YOUR HEART",
        message: "Your love makes the people around you feel valued, cared for, and at home."
      },
      {
        id: "kindness",
        number: "02",
        title: "YOUR KINDNESS",
        message: "The little things you do can mean more than the biggest gifts."
      },
      {
        id: "strength",
        number: "03",
        title: "YOUR STRENGTH",
        message: "Your strength is a reminder that difficult days do not define the whole story."
      },
      {
        id: "presence",
        number: "04",
        title: "YOUR PRESENCE",
        message: "There is something special about having you near. You make ordinary moments meaningful."
      },
      {
        id: "smile",
        number: "05",
        title: "YOUR SMILE",
        message: "Your happiness brings warmth into moments that might otherwise feel ordinary."
      },
      {
        id: "faith",
        number: "06",
        title: "YOUR FAITH",
        message: "May your faith continue to bring you hope, peace, and strength through every season of life."
      }
    ]
  },

  // Chapter 6: A Prayer for Maa
  chapterSix: {
    headline: "A PRAYER FOR YOUR LIFE, MAA",
    introduction: "Before we celebrate another year, let us thank God for the gift of your life.",
    prayer: [
      "Heavenly Father,",
      "Thank You for the precious gift of Maa's life.",
      "Thank You for bringing her into our lives and for the love, memories, and moments we are blessed to share with her.",
      "Lord, please guide her in the year ahead.",
      "Fill her heart with Your peace.",
      "Give her strength when days are difficult, wisdom when decisions are uncertain, and joy in the little blessings of everyday life.",
      "Surround her with people who genuinely care for her.",
      "Help her feel loved, valued, and appreciated.",
      "May her home be filled with peace, her heart with hope, and her days with reasons to smile.",
      "Bless the dreams she carries, the work of her hands, and the paths she will walk.",
      "May Your grace sustain her, Your wisdom guide her, and Your love remind her that she is never alone.",
      "Thank You for the blessing of having her in our lives.",
      "In Jesus' name, Amen."
    ],
    verse: {
      lines: [
        "May the LORD bless you and keep you;",
        "the LORD make his face shine on you",
        "and be gracious to you;",
        "the LORD turn his face toward you",
        "and give you peace."
      ],
      reference: "— Numbers 6:24–26"
    }
  },

  // Chapter 7: The Countdown
  chapterSeven: {
    headline: "Maa, your special moment is here.",
    supportingText: "A little wish. A beautiful new year. A moment just for you.",
    startButton: "LET THE CELEBRATION BEGIN",
    wishButton: "MAKE YOUR WISH"
  },

  // Chapter 8: The Grand Birthday Reveal
  chapterEight: {
    introTag: "AND NOW...",
    subTag: "A MOMENT JUST FOR YOU.",
    greeting: "HAPPY BIRTHDAY",
    name: "MAA ❤️",
    portraitPath: "/images/maa-portrait.jpg",
    paragraphs: [
      "Today, we celebrate you.",
      "Your life, your love, your beautiful presence, and all the little things that make you irreplaceable.",
      "May this new year bring you peace in your heart, joy in your days, strength for every challenge, and countless beautiful moments to treasure.",
      "May God's grace guide you, His love surround you, and His blessings follow you wherever life takes you.",
      "You deserve to feel celebrated, appreciated, and deeply loved—not just today, but every day.",
      "Happy Birthday, Maa.",
      "You are one of the most precious blessings in our lives."
    ],
    closingSignature: "With love, today and always."
  }
};
