/**
 * Centralized memory gallery data for Chapter 3.
 *
 * Configurable paths:
 * /images/maa-1.jpg
 * /images/maa-2.jpg
 * /images/maa-3.jpg
 * /images/maa-4.jpg
 * /images/maa-5.jpg
 */

export interface MemoryItem {
  id: string;
  image: string;
  caption: string;
  subheading?: string;
  placeholderTitle: string;
}

export const memories: MemoryItem[] = [
  {
    id: "mem-1",
    image: "/images/maa-1.jpg",
    caption: "A moment worth remembering.",
    subheading: "Unconditional warmth & gentle grace",
    placeholderTitle: "A Precious Beginning"
  },
  {
    id: "mem-2",
    image: "/images/maa-2.jpg",
    caption: "The smile that brightens our home.",
    subheading: "Where laughter and peace reside",
    placeholderTitle: "Warmth of Home"
  },
  {
    id: "mem-3",
    image: "/images/maa-3.jpg",
    caption: "A memory we will always treasure.",
    subheading: "Selfless love in everyday moments",
    placeholderTitle: "Treasured Moments"
  },
  {
    id: "mem-4",
    image: "/images/maa-4.jpg",
    caption: "A beautiful part of our story.",
    subheading: "Guided by your boundless wisdom",
    placeholderTitle: "Our Guiding Light"
  },
  {
    id: "mem-5",
    image: "/images/maa-5.jpg",
    caption: "The moments we wish could last a little longer.",
    subheading: "Grace and kindness in every breath",
    placeholderTitle: "Gentle Strength"
  },
  {
    id: "mem-6",
    image: "/images/maa-portrait.jpg",
    caption: "The love that holds our family together.",
    subheading: "Forever cherished, honored, and loved",
    placeholderTitle: "Boundless Love"
  }
];
