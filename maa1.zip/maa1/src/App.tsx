import React, { useState, useEffect, useCallback } from "react";
import { ChapterLayout } from "./components/ChapterLayout";
import { ChapterNavigation } from "./components/ChapterNavigation";
import { ChapterOne } from "./chapters/ChapterOne";
import { ChapterTwo } from "./chapters/ChapterTwo";
import { ChapterThree } from "./chapters/ChapterThree";
import { ChapterFour } from "./chapters/ChapterFour";
import { ChapterFive } from "./chapters/ChapterFive";
import { ChapterSix } from "./chapters/ChapterSix";
import { ChapterSeven } from "./chapters/ChapterSeven";
import { ChapterEight } from "./chapters/ChapterEight";

const CHAPTER_TITLES = [
  "The Mysterious Beginning",
  "A Story Written in Love",
  "Her Beautiful Memories",
  "A Letter for Maa",
  "Six Special Reminders",
  "A Prayer for Maa",
  "The Birthday Countdown",
  "The Grand Birthday Reveal"
];

export default function App() {
  const [currentChapter, setCurrentChapter] = useState<number>(1);
  const [isTransitioning, setIsTransitioning] = useState<boolean>(false);

  // Scroll to top cleanly when chapter changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [currentChapter]);

  const changeChapter = useCallback(
    (newChapter: number) => {
      if (newChapter < 1 || newChapter > 8 || newChapter === currentChapter) return;
      if (isTransitioning) return;

      setIsTransitioning(true);
      setCurrentChapter(newChapter);

      // Brief transition debounce to prevent rapid clicking glitches
      setTimeout(() => {
        setIsTransitioning(false);
      }, 400);
    },
    [currentChapter, isTransitioning]
  );

  const handleNext = () => {
    if (currentChapter < 8) {
      changeChapter(currentChapter + 1);
    }
  };

  const handleBack = () => {
    if (currentChapter > 1) {
      changeChapter(currentChapter - 1);
    }
  };

  const handleRestart = () => {
    changeChapter(1);
  };

  const handleRevisitMemories = () => {
    changeChapter(3);
  };

  // Keyboard navigation support for left/right arrows if not in input
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }
      if (e.key === "ArrowRight" && currentChapter < 8 && currentChapter !== 7) {
        handleNext();
      } else if (e.key === "ArrowLeft" && currentChapter > 1) {
        handleBack();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentChapter, handleNext, handleBack]);

  const isDarkTheme = currentChapter === 1 || currentChapter === 7 || currentChapter === 8;

  const renderCurrentChapter = () => {
    switch (currentChapter) {
      case 1:
        return <ChapterOne onBegin={() => changeChapter(2)} />;
      case 2:
        return <ChapterTwo onContinue={() => changeChapter(3)} />;
      case 3:
        return <ChapterThree />;
      case 4:
        return <ChapterFour />;
      case 5:
        return <ChapterFive />;
      case 6:
        return <ChapterSix />;
      case 7:
        return <ChapterSeven onWishCompleted={() => changeChapter(8)} />;
      case 8:
        return (
          <ChapterEight
            onRevisitMemories={handleRevisitMemories}
            onRestart={handleRestart}
          />
        );
      default:
        return <ChapterOne onBegin={() => changeChapter(2)} />;
    }
  };

  // Dynamic next button label depending on current narrative chapter
  const getNextLabel = () => {
    switch (currentChapter) {
      case 1:
        return "Begin Surprise";
      case 2:
        return "Explore Memories";
      case 3:
        return "Read Her Letter";
      case 4:
        return "See Reminders";
      case 5:
        return "Join In Prayer";
      case 6:
        return "Ready The Celebration";
      case 7:
        return "Skip to Reveal";
      default:
        return "Continue";
    }
  };

  return (
    <ChapterLayout
      currentChapter={currentChapter}
      totalChapters={8}
      chapterTitles={CHAPTER_TITLES}
      onSelectChapter={changeChapter}
    >
      {/* Chapter View */}
      <div className="w-full transition-opacity duration-500">
        {renderCurrentChapter()}
      </div>

      {/* Global Navigation Controls */}
      <ChapterNavigation
        currentChapter={currentChapter}
        totalChapters={8}
        canGoBack={currentChapter > 1}
        canGoNext={currentChapter < 8}
        nextLabel={getNextLabel()}
        onBack={handleBack}
        onNext={handleNext}
        onRestart={handleRestart}
        isDarkTheme={isDarkTheme}
        isBusy={isTransitioning}
      />
    </ChapterLayout>
  );
}
