import React, { useState, useEffect, useRef } from "react";
import { birthdayContent } from "../data/birthdayContent";
import { Heart, Gift, Shield, Compass, Sun, BookOpen, Check } from "lucide-react";
import { triggerWaterRipple } from "./WaterCanvas";
import anime from "animejs";

export const LoveCards: React.FC = () => {
  const { cards } = birthdayContent.chapterFive;
  const [openedCards, setOpenedCards] = useState<Set<string>>(new Set());
  const gridRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (gridRef.current) {
      const cardEls = gridRef.current.querySelectorAll(".love-card-item");
      anime({
        targets: cardEls,
        opacity: [0, 1],
        translateY: [25, 0],
        scale: [0.96, 1],
        delay: anime.stagger(120),
        duration: 800,
        easing: "easeOutCubic"
      });
    }
  }, []);

  const toggleCard = (id: string, e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    triggerWaterRipple(rect.left + rect.width / 2, rect.top + rect.height / 2, 0.7);

    setOpenedCards((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const getIcon = (id: string) => {
    switch (id) {
      case "heart":
        return <Heart className="w-5 h-5 text-[#55B7E8] fill-[#55B7E8]/20" />;
      case "kindness":
        return <Gift className="w-5 h-5 text-[#55B7E8]" />;
      case "strength":
        return <Shield className="w-5 h-5 text-[#55B7E8]" />;
      case "presence":
        return <Compass className="w-5 h-5 text-[#55B7E8]" />;
      case "smile":
        return <Sun className="w-5 h-5 text-[#55B7E8]" />;
      case "faith":
        return <BookOpen className="w-5 h-5 text-[#55B7E8]" />;
      default:
        return <Heart className="w-5 h-5 text-[#55B7E8]" />;
    }
  };

  const allOpened = openedCards.size === cards.length;

  return (
    <div className="w-full max-w-4xl mx-auto select-none">
      {/* Cards 2-Column Grid */}
      <div ref={gridRef} className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
        {cards.map((card) => {
          const isOpen = openedCards.has(card.id);

          return (
            <div
              key={card.id}
              role="button"
              tabIndex={0}
              aria-expanded={isOpen}
              aria-label={`${card.title}: ${isOpen ? "Opened" : "Click to reveal reminder"}`}
              onClick={(e) => toggleCard(card.id, e)}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  const target = e.currentTarget;
                  const rect = target.getBoundingClientRect();
                  triggerWaterRipple(rect.left + rect.width / 2, rect.top + rect.height / 2, 0.7);
                  setOpenedCards((prev) => {
                    const next = new Set(prev);
                    if (next.has(card.id)) next.delete(card.id);
                    else next.add(card.id);
                    return next;
                  });
                }
              }}
              className={`love-card-item opacity-0 relative text-left p-6 rounded-2xl transition-all duration-400 border cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#55B7E8] ${
                isOpen
                  ? "glass-water-card bg-[#123B70]/80 border-[#55B7E8] shadow-[0_15px_35px_rgba(85,183,232,0.3)] scale-[1.01]"
                  : "glass-water-card bg-[#123B70]/40 border-[#55B7E8]/25 hover:border-[#55B7E8]/60 hover:bg-[#123B70]/60 hover:-translate-y-1 shadow-md"
              }`}
            >
              {/* Header row */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3.5">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors border ${
                      isOpen
                        ? "bg-[#1769AA] border-[#55B7E8] shadow-[0_0_15px_rgba(85,183,232,0.5)]"
                        : "bg-[#071A33]/70 border-[#55B7E8]/30"
                    }`}
                  >
                    {getIcon(card.id)}
                  </div>
                  <div>
                    <span className="block text-[11px] font-sans tracking-widest uppercase text-[#55B7E8] font-semibold">
                      {card.number}
                    </span>
                    <h3 className="font-serif text-lg sm:text-xl font-bold text-[#F4FAFF] tracking-wide">
                      {card.title}
                    </h3>
                  </div>
                </div>

                {/* State Tag */}
                <div className="shrink-0">
                  {isOpen ? (
                    <span className="flex items-center gap-1 text-xs font-serif italic text-[#55B7E8] font-medium">
                      <Check className="w-3.5 h-3.5 text-[#55B7E8]" />
                      <span>Revealed</span>
                    </span>
                  ) : (
                    <span className="text-xs font-serif italic text-[#D9F2FF]/60 hover:text-[#55B7E8]">
                      Tap to open
                    </span>
                  )}
                </div>
              </div>

              {/* Message Body */}
              <div className="pt-2 border-t border-[#55B7E8]/20 min-h-[64px] flex items-center">
                {isOpen ? (
                  <p className="font-serif text-[#F4FAFF] text-base sm:text-lg leading-relaxed font-normal animate-fade-in">
                    "{card.message}"
                  </p>
                ) : (
                  <p className="font-serif italic text-xs sm:text-sm text-[#D9F2FF]/60">
                    Click to uncover a special thought about your {card.title.toLowerCase().replace("your ", "")}...
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Progress helper */}
      <div className="mt-8 text-center text-xs font-serif italic text-[#D9F2FF]/70">
        {allOpened ? (
          <span className="text-[#55B7E8] font-medium">
            All six reasons opened with deep love and gratitude.
          </span>
        ) : (
          <span>
            {openedCards.size} of 6 reminders explored. Open as many as you wish before continuing.
          </span>
        )}
      </div>
    </div>
  );
};
