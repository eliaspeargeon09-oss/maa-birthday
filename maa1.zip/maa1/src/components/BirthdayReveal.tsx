import React, { useState, useEffect, useRef } from "react";
import { birthdayContent } from "../data/birthdayContent";
import { Sparkles, Heart, RotateCcw, Image as ImageIcon } from "lucide-react";
import { ConfettiCanvas } from "./ConfettiCanvas";
import { triggerWaterRipple } from "./WaterCanvas";
import anime from "animejs";

interface BirthdayRevealProps {
  onRevisitMemories: () => void;
  onRestart: () => void;
}

export const BirthdayReveal: React.FC<BirthdayRevealProps> = ({
  onRevisitMemories,
  onRestart
}) => {
  const { chapterEight } = birthdayContent;
  const [confettiKey, setConfettiKey] = useState<number>(1);
  const [imageError, setImageError] = useState(false);

  const containerRef = useRef<HTMLDivElement | null>(null);
  const tagRef = useRef<HTMLParagraphElement | null>(null);
  const subTagRef = useRef<HTMLParagraphElement | null>(null);
  const greetingRef = useRef<HTMLHeadingElement | null>(null);
  const nameRef = useRef<HTMLHeadingElement | null>(null);
  const portraitRef = useRef<HTMLDivElement | null>(null);
  const messageRef = useRef<HTMLDivElement | null>(null);
  const actionsRef = useRef<HTMLDivElement | null>(null);

  const runRevealSequence = () => {
    // Fire confetti and surface water ripple
    setConfettiKey((prev) => prev + 1);
    triggerWaterRipple(window.innerWidth / 2, window.innerHeight / 2, 1.5);

    const tl = anime.timeline({
      easing: "easeOutCubic"
    });

    if (tagRef.current) {
      tl.add({
        targets: tagRef.current,
        opacity: [0, 1],
        translateY: [15, 0],
        duration: 750
      });
    }

    if (subTagRef.current) {
      tl.add({
        targets: subTagRef.current,
        opacity: [0, 1],
        translateY: [15, 0],
        duration: 750,
        offset: "-=300"
      });
    }

    if (greetingRef.current) {
      tl.add({
        targets: greetingRef.current,
        opacity: [0, 1],
        translateY: [25, 0],
        duration: 900,
        offset: "-=300"
      });
    }

    if (nameRef.current) {
      tl.add({
        targets: nameRef.current,
        opacity: [0, 1],
        scale: [0.85, 1],
        duration: 1000,
        easing: "easeOutBack",
        offset: "-=400"
      });
    }

    if (portraitRef.current) {
      tl.add({
        targets: portraitRef.current,
        opacity: [0, 1],
        translateY: [30, 0],
        scale: [0.96, 1],
        duration: 900,
        offset: "-=500"
      });
    }

    if (messageRef.current) {
      tl.add({
        targets: messageRef.current,
        opacity: [0, 1],
        translateY: [20, 0],
        duration: 900,
        offset: "-=400"
      });
    }

    if (actionsRef.current) {
      tl.add({
        targets: actionsRef.current,
        opacity: [0, 1],
        translateY: [15, 0],
        duration: 800,
        offset: "-=300"
      });
    }
  };

  useEffect(() => {
    runRevealSequence();
  }, []);

  const handleWatchAgain = () => {
    runRevealSequence();
  };

  return (
    <div
      ref={containerRef}
      className="w-full max-w-4xl mx-auto flex flex-col items-center text-center pb-8 select-none relative z-10"
    >
      {/* Confetti celebration canvas */}
      <ConfettiCanvas triggerKey={confettiKey} />

      {/* Atmospheric center glow */}
      <div
        className="w-96 sm:w-[500px] h-96 sm:h-[500px] rounded-full bg-gradient-to-r from-[#1769AA]/40 via-[#55B7E8]/25 to-[#123B70]/40 blur-3xl absolute pointer-events-none -z-10 animate-water-glow"
        aria-hidden="true"
      />

      {/* Opening Reveal: 1. "AND NOW..." */}
      <p
        ref={tagRef}
        className="font-serif tracking-[0.35em] uppercase text-xs sm:text-sm text-[#55B7E8] mb-2 opacity-0 font-semibold"
      >
        {chapterEight.introTag}
      </p>

      {/* Opening Reveal: 2. "A MOMENT JUST FOR YOU." */}
      <p
        ref={subTagRef}
        className="font-serif italic text-base sm:text-xl text-[#D9F2FF]/85 mb-4 opacity-0"
      >
        {chapterEight.subTag}
      </p>

      {/* Opening Reveal: 3. "HAPPY BIRTHDAY" */}
      <h1
        ref={greetingRef}
        className="font-serif text-4xl sm:text-6xl md:text-7xl font-bold tracking-tight text-[#F4FAFF] drop-shadow-[0_10px_35px_rgba(85,183,232,0.4)] leading-tight mb-2 opacity-0"
      >
        {chapterEight.greeting}
      </h1>

      {/* Opening Reveal: 4. "MAA ❤️" */}
      <div className="flex items-center justify-center gap-3 mb-8">
        <h2
          ref={nameRef}
          className="font-serif italic text-5xl sm:text-7xl md:text-8xl text-transparent bg-clip-text bg-gradient-to-r from-[#55B7E8] via-[#F4FAFF] to-[#55B7E8] font-bold drop-shadow-[0_10px_35px_rgba(85,183,232,0.6)] opacity-0"
        >
          {chapterEight.name}
        </h2>
      </div>

      {/* Maa's Portrait Frame with Graceful Fallback */}
      <div ref={portraitRef} className="relative my-4 group opacity-0">
        {/* Soft sapphire halo glow */}
        <div
          className="absolute -inset-4 bg-gradient-to-r from-[#55B7E8]/30 via-[#1769AA]/20 to-[#55B7E8]/30 rounded-3xl blur-2xl animate-water-glow pointer-events-none"
          aria-hidden="true"
        />

        {/* Archival Keepsake Frame */}
        <div className="relative w-64 sm:w-76 md:w-80 aspect-[3/4] rounded-2xl p-3 bg-gradient-to-b from-[#55B7E8] via-[#1769AA] to-[#071A33] shadow-[0_20px_50px_rgba(7,26,51,0.9)] border-2 border-[#55B7E8]/60">
          <div className="relative w-full h-full rounded-xl overflow-hidden bg-[#071A33] border border-[#55B7E8]/30 flex items-center justify-center">
            {!imageError ? (
              <img
                src={chapterEight.portraitPath}
                alt="Beloved Maa Portrait"
                referrerPolicy="no-referrer"
                onError={() => setImageError(true)}
                className="w-full h-full object-cover"
              />
            ) : null}

            {/* Graceful Archival Mat (Rendered when custom portrait is not yet placed) */}
            {imageError && (
              <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-[#123B70] via-[#071A33] to-[#1769AA]">
                {/* Sapphire Embossed Monogram */}
                <div className="w-20 h-20 rounded-full border-2 border-[#55B7E8] bg-[#071A33] text-[#55B7E8] flex items-center justify-center mb-4 shadow-[0_0_20px_rgba(85,183,232,0.4)]">
                  <span className="font-serif font-bold text-4xl italic">M</span>
                </div>
                <h4 className="font-serif text-2xl text-[#F4FAFF] font-semibold">
                  Maa
                </h4>
                <p className="font-serif italic text-xs sm:text-sm text-[#D9F2FF]/80 mt-1 max-w-[200px]">
                  "You are one of the most precious blessings in our lives."
                </p>
                <div className="mt-4 pt-3 border-t border-[#55B7E8]/30 flex items-center gap-1.5 text-[10px] font-sans uppercase tracking-wider text-[#55B7E8]">
                  <ImageIcon className="w-3.5 h-3.5 text-[#55B7E8]" />
                  <span>Place photo in /public/images/maa-portrait.jpg</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Small portrait caption */}
        <p className="font-serif italic text-xs sm:text-sm text-[#55B7E8] mt-3">
          Our Heart, Our Anchor, Our Maa
        </p>
      </div>

      {/* Narrative Message Card */}
      <div
        ref={messageRef}
        className="mt-8 max-w-2xl mx-auto px-6 sm:px-10 py-8 sm:py-10 glass-water-card bg-[#071A33]/85 backdrop-blur-md rounded-2xl sm:rounded-3xl border border-[#55B7E8]/35 shadow-2xl text-left opacity-0"
      >
        <div className="space-y-4 font-serif text-lg sm:text-xl leading-relaxed text-[#F4FAFF]">
          {chapterEight.paragraphs.map((para, i) => (
            <p key={i} className="text-[#D9F2FF]/95">
              {para}
            </p>
          ))}
        </div>

        {/* Final Decorative Closing */}
        <div className="mt-8 pt-6 border-t border-[#55B7E8]/20 flex flex-col items-center text-center">
          <Heart className="w-5 h-5 text-[#55B7E8] mb-2 fill-[#55B7E8]/30" />
          <p className="font-['Alex_Brush',cursive] text-3xl sm:text-4xl text-[#F4FAFF] drop-shadow-md">
            {chapterEight.closingSignature}
          </p>
        </div>
      </div>

      {/* Action Buttons: Relive Memories, Watch Reveal Again, Restart */}
      <div
        ref={actionsRef}
        className="mt-10 flex flex-wrap items-center justify-center gap-3 sm:gap-4 opacity-0"
      >
        <button
          type="button"
          onClick={onRevisitMemories}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#123B70] text-[#F4FAFF] hover:bg-[#1769AA] border border-[#55B7E8]/40 font-semibold text-xs sm:text-sm tracking-wider uppercase transition-all shadow-md hover:scale-105 active:scale-95 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#55B7E8]"
        >
          <ImageIcon className="w-4 h-4 text-[#55B7E8]" />
          <span>RELIVE OUR MEMORIES</span>
        </button>

        <button
          type="button"
          onClick={handleWatchAgain}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-[#1769AA] via-[#55B7E8] to-[#1769AA] text-[#071A33] hover:shadow-[0_10px_25px_rgba(85,183,232,0.5)] font-bold text-xs sm:text-sm tracking-wider uppercase transition-all shadow-md hover:scale-105 active:scale-95 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#55B7E8]"
        >
          <Sparkles className="w-4 h-4 text-[#071A33]" />
          <span>WATCH THE REVEAL AGAIN</span>
        </button>

        <button
          type="button"
          onClick={onRestart}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-transparent text-[#D9F2FF] hover:text-[#F4FAFF] hover:bg-white/10 font-semibold text-xs sm:text-sm tracking-wider uppercase transition-all border border-[#55B7E8]/30 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#55B7E8]"
        >
          <RotateCcw className="w-4 h-4 text-[#55B7E8]" />
          <span>START OUR JOURNEY AGAIN</span>
        </button>
      </div>
    </div>
  );
};
