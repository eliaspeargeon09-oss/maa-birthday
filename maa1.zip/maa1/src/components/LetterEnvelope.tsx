import React, { useState, useRef, useEffect } from "react";
import { birthdayContent } from "../data/birthdayContent";
import { Mail, MailOpen, Heart, Sparkles } from "lucide-react";
import anime from "animejs";

export const LetterEnvelope: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const letter = birthdayContent.chapterFour;
  const envelopeCardRef = useRef<HTMLDivElement | null>(null);
  const letterCardRef = useRef<HTMLDivElement | null>(null);

  const handleOpenLetter = () => {
    if (envelopeCardRef.current && !isOpen) {
      anime({
        targets: envelopeCardRef.current,
        scale: [1, 0.95],
        opacity: [1, 0],
        duration: 400,
        easing: "easeInOutQuad",
        complete: () => {
          setIsOpen(true);
        }
      });
    } else {
      setIsOpen(true);
    }
  };

  useEffect(() => {
    if (isOpen && letterCardRef.current) {
      const paragraphs = letterCardRef.current.querySelectorAll(".letter-p");
      anime.timeline({ easing: "easeOutCubic" })
        .add({
          targets: letterCardRef.current,
          opacity: [0, 1],
          translateY: [30, 0],
          scale: [0.97, 1],
          duration: 750
        })
        .add({
          targets: paragraphs,
          opacity: [0, 1],
          translateY: [15, 0],
          delay: anime.stagger(150),
          duration: 650,
          offset: "-=300"
        });
    }
  }, [isOpen]);

  const handleFoldBack = () => {
    setIsOpen(false);
  };

  return (
    <div className="w-full max-w-3xl mx-auto flex flex-col items-center select-none relative z-10">
      {!isOpen ? (
        /* Sealed Luxury Physical Envelope View */
        <div ref={envelopeCardRef} className="w-full flex flex-col items-center">
          {/* Envelope Card */}
          <div
            role="button"
            tabIndex={0}
            onClick={handleOpenLetter}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                handleOpenLetter();
              }
            }}
            aria-label="Click to open letter for Maa"
            className="group relative w-full aspect-[16/10] max-w-lg glass-water-card bg-[#123B70]/70 rounded-2xl shadow-[0_25px_60px_rgba(7,26,51,0.9)] border-2 border-[#55B7E8]/50 p-6 sm:p-8 flex flex-col items-center justify-between cursor-pointer hover:shadow-[0_25px_65px_rgba(85,183,232,0.35)] transition-all duration-500 hover:-translate-y-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#55B7E8]"
          >
            {/* Geometric envelope flap simulation */}
            <div
              className="absolute inset-x-0 top-0 h-1/2 bg-[#1769AA]/50 border-b border-[#55B7E8]/40 [clip-path:polygon(0_0,100%_0,50%_100%)] transition-transform duration-500 origin-top group-hover:scale-y-95 backdrop-blur-xs"
              aria-hidden="true"
            />

            {/* Ocean postage stamp corner */}
            <div className="absolute top-4 right-4 w-12 h-14 border border-dashed border-[#55B7E8]/50 rounded-md bg-[#071A33]/80 p-1 flex flex-col items-center justify-center text-center shadow-md">
              <Heart className="w-4 h-4 text-[#55B7E8] fill-[#55B7E8]/20" />
              <span className="text-[8px] font-sans uppercase tracking-widest text-[#D9F2FF]/80 mt-1">
                FOR MAA
              </span>
            </div>

            {/* Spacer */}
            <div className="h-4" />

            {/* Sapphire Wax Seal & Title */}
            <div className="relative z-10 flex flex-col items-center text-center my-auto">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#55B7E8] via-[#1769AA] to-[#071A33] text-[#F4FAFF] border-2 border-[#D9F2FF] shadow-[0_0_25px_rgba(85,183,232,0.6)] flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                <span className="font-serif italic font-bold text-2xl tracking-wider">M</span>
              </div>
              <h3 className="font-serif italic text-2xl sm:text-3xl text-[#F4FAFF] font-semibold tracking-wide drop-shadow-md">
                "{letter.envelopeTitle}"
              </h3>
              <p className="font-sans text-xs tracking-wider uppercase text-[#D9F2FF]/70 mt-1.5">
                Handwritten with infinite love
              </p>
            </div>

            {/* Bottom accent hint */}
            <div className="relative z-10 text-xs font-serif italic text-[#D9F2FF]/80 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#55B7E8]" />
              <span>Click envelope to open</span>
            </div>

            {/* Subtle water reflection beneath envelope */}
            <div className="absolute -bottom-6 inset-x-8 h-6 bg-gradient-to-b from-[#55B7E8]/15 to-transparent blur-md pointer-events-none rounded-full" />
          </div>

          {/* Explicit Open Button */}
          <div className="mt-8">
            <button
              type="button"
              onClick={handleOpenLetter}
              className="inline-flex items-center gap-2.5 px-8 py-3.5 bg-gradient-to-r from-[#1769AA] via-[#55B7E8] to-[#1769AA] text-[#071A33] hover:shadow-[0_10px_30px_rgba(85,183,232,0.5)] rounded-full font-semibold text-sm tracking-widest uppercase transition-all duration-300 hover:scale-105 active:scale-95 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#55B7E8]"
            >
              <Mail className="w-4 h-4 text-[#071A33]" />
              <span>{letter.openButton}</span>
            </button>
          </div>
        </div>
      ) : (
        /* Unfolded Letter Parchment View */
        <div ref={letterCardRef} className="w-full flex flex-col items-center opacity-0">
          <div className="relative w-full glass-water-card bg-[#071A33]/90 text-[#F4FAFF] rounded-2xl sm:rounded-3xl shadow-[0_25px_60px_rgba(7,26,51,0.95)] border border-[#55B7E8]/40 p-7 sm:p-12 md:p-14">
            {/* Elegant corner flourishes */}
            <div
              className="absolute top-4 left-4 w-6 h-6 border-t-2 border-l-2 border-[#55B7E8]/40 rounded-tl-sm pointer-events-none"
              aria-hidden="true"
            />
            <div
              className="absolute top-4 right-4 w-6 h-6 border-t-2 border-r-2 border-[#55B7E8]/40 rounded-tr-sm pointer-events-none"
              aria-hidden="true"
            />
            <div
              className="absolute bottom-4 left-4 w-6 h-6 border-b-2 border-l-2 border-[#55B7E8]/40 rounded-bl-sm pointer-events-none"
              aria-hidden="true"
            />
            <div
              className="absolute bottom-4 right-4 w-6 h-6 border-b-2 border-r-2 border-[#55B7E8]/40 rounded-br-sm pointer-events-none"
              aria-hidden="true"
            />

            {/* Letter Salutation */}
            <div className="mb-6">
              <h3 className="font-serif text-3xl sm:text-4xl text-[#55B7E8] font-bold italic tracking-wide">
                {letter.letterSalutation}
              </h3>
            </div>

            {/* Letter Paragraphs */}
            <div className="space-y-4 sm:space-y-5 text-base sm:text-lg leading-relaxed sm:leading-loose text-[#D9F2FF]/95 font-serif">
              {letter.paragraphs.map((paragraph, idx) => (
                <p key={idx} className="letter-p opacity-0">
                  {paragraph}
                </p>
              ))}
            </div>

            {/* Handwritten Signature */}
            <div className="mt-10 sm:mt-12 pt-6 border-t border-[#55B7E8]/20 flex flex-col sm:flex-row items-baseline justify-between gap-4">
              <div>
                <span className="block text-xs uppercase tracking-widest text-[#55B7E8] font-sans mb-1">
                  Forever Your Child
                </span>
                <p className="font-['Alex_Brush',cursive] text-4xl sm:text-5xl text-[#F4FAFF] drop-shadow-md">
                  {letter.signature}
                </p>
              </div>

              <button
                type="button"
                onClick={handleFoldBack}
                className="inline-flex items-center gap-1.5 text-xs text-[#B8D8EA] hover:text-[#55B7E8] transition-colors cursor-pointer font-sans"
              >
                <MailOpen className="w-3.5 h-3.5 text-[#55B7E8]" />
                <span>Fold letter back</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
