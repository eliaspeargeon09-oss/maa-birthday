import React, { useState, useEffect, useRef } from "react";
import { Sparkles, Wind, RotateCcw } from "lucide-react";
import { triggerWaterRipple } from "./WaterCanvas";
import { musicManager } from "../utils/audioController";
import anime from "animejs";

interface BirthdayCakeProps {
  onWishMade: () => void;
}

export const BirthdayCake: React.FC<BirthdayCakeProps> = ({ onWishMade }) => {
  const [phase, setPhase] = useState<"idle" | "counting" | "ready-to-wish" | "blown-out">("idle");
  const [countdown, setCountdown] = useState<number>(5);
  const countdownElRef = useRef<HTMLSpanElement | null>(null);
  const flamesRef = useRef<SVGGElement | null>(null);
  const timerRef = useRef<number | null>(null);

  // Clean up any pending timer
  useEffect(() => {
    return () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    };
  }, []);

  // Animate countdown numbers using Anime.js
  useEffect(() => {
    if (phase === "counting" && countdownElRef.current) {
      anime({
        targets: countdownElRef.current,
        scale: [0.4, 1.15, 1],
        opacity: [0, 1],
        duration: 850,
        easing: "easeOutElastic(1, .6)"
      });
    }
  }, [phase, countdown]);

  useEffect(() => {
    if (phase === "counting") {
      if (countdown > 1) {
        timerRef.current = window.setTimeout(() => {
          setCountdown((prev) => prev - 1);
        }, 1100);
      } else {
        // Reached 1: pause briefly then move to ready-to-wish
        timerRef.current = window.setTimeout(() => {
          setPhase("ready-to-wish");
        }, 1200);
      }
    }
    return () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    };
  }, [phase, countdown]);

  const handleStartCountdown = (e: React.MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    triggerWaterRipple(rect.left + rect.width / 2, rect.top + rect.height / 2, 0.9);
    setCountdown(5);
    setPhase("counting");
  };

  const handleReset = () => {
    if (timerRef.current) window.clearTimeout(timerRef.current);
    setCountdown(5);
    setPhase("idle");
  };

  const handleBlowCandles = (e: React.MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    triggerWaterRipple(rect.left + rect.width / 2, rect.top + rect.height / 2, 1.4);
    musicManager.playCandleBlow();

    setPhase("blown-out");

    // Animate flames extinguishing
    if (flamesRef.current) {
      anime({
        targets: flamesRef.current,
        scaleY: [1, 0.1],
        opacity: [1, 0],
        duration: 400,
        easing: "easeOutQuad"
      });
    }

    timerRef.current = window.setTimeout(() => {
      onWishMade();
    }, 1500);
  };

  const candlesLit = phase !== "blown-out";

  return (
    <div className="w-full max-w-xl mx-auto flex flex-col items-center select-none relative z-10">
      {/* Handcrafted SVG Multi-Tier Birthday Cake in Oceanic Palette */}
      <div className="relative w-72 sm:w-84 h-72 sm:h-84 flex items-center justify-center my-4">
        {/* Soft water illumination aura behind cake */}
        <div
          className={`absolute inset-0 rounded-full bg-[#55B7E8]/20 blur-3xl transition-opacity duration-1000 ${
            candlesLit ? "opacity-100" : "opacity-10"
          }`}
          aria-hidden="true"
        />

        <svg
          viewBox="0 0 320 320"
          className="w-full h-full drop-shadow-[0_20px_35px_rgba(7,26,51,0.9)]"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Cake Stand / Pedestal */}
          <ellipse cx="160" cy="275" rx="100" ry="12" fill="#123B70" opacity="0.6" />
          <path
            d="M80 270 Q160 285 240 270 L230 282 Q160 292 90 282 Z"
            fill="url(#standGradient)"
          />
          <ellipse cx="160" cy="270" rx="80" ry="10" fill="#F4FAFF" opacity="0.9" />

          {/* Tier 1 (Bottom Tier) - Midnight Ocean Blue */}
          <path
            d="M90 220 C90 220 90 265 90 265 C90 273 230 273 230 265 C230 265 230 220 230 220 Z"
            fill="#123B70"
          />
          <ellipse cx="160" cy="220" rx="70" ry="14" fill="#1769AA" />
          {/* Silver-blue filigree icing on bottom tier */}
          <path
            d="M92 238 Q106 248 120 238 Q134 248 148 238 Q162 248 176 238 Q190 248 204 238 Q218 248 228 238"
            stroke="#55B7E8"
            strokeWidth="2.5"
            strokeLinecap="round"
          />

          {/* Tier 2 (Middle Tier) - Pale Blue-White */}
          <path
            d="M110 165 C110 165 110 215 110 215 C110 222 210 222 210 215 C210 215 210 165 210 165 Z"
            fill="#F4FAFF"
          />
          <ellipse cx="160" cy="165" rx="50" ry="11" fill="#FFFFFF" />
          {/* Soft ice blue icing drip */}
          <path
            d="M110 178 C115 190 125 190 130 178 C135 192 145 192 150 178 C155 190 165 190 170 178 C175 192 185 192 190 178 C195 190 205 190 210 178"
            fill="#D9F2FF"
            opacity="0.9"
          />

          {/* Tier 3 (Top Tier) - Sapphire */}
          <path
            d="M125 125 C125 125 125 160 125 160 C125 166 195 166 195 160 C195 160 195 125 195 125 Z"
            fill="#123B70"
          />
          <ellipse cx="160" cy="125" rx="35" ry="8" fill="#1769AA" />
          {/* Pearl bead garnish */}
          <circle cx="135" cy="132" r="3" fill="#D9F2FF" />
          <circle cx="150" cy="134" r="3" fill="#D9F2FF" />
          <circle cx="165" cy="134" r="3" fill="#D9F2FF" />
          <circle cx="180" cy="132" r="3" fill="#D9F2FF" />

          {/* Candle 1 (Left) */}
          <rect x="137" y="90" width="6" height="32" rx="2" fill="url(#candleGradient)" />
          <line x1="140" y1="90" x2="140" y2="85" stroke="#071A33" strokeWidth="1.5" />

          {/* Candle 2 (Center - taller/main) */}
          <rect x="157" y="82" width="6" height="40" rx="2" fill="url(#candleGradient)" />
          <line x1="160" y1="82" x2="160" y2="76" stroke="#071A33" strokeWidth="1.5" />

          {/* Candle 3 (Right) */}
          <rect x="177" y="90" width="6" height="32" rx="2" fill="url(#candleGradient)" />
          <line x1="180" y1="90" x2="180" y2="85" stroke="#071A33" strokeWidth="1.5" />

          {/* Candle Flames Group */}
          {candlesLit && (
            <g ref={flamesRef}>
              {/* Flame 1 */}
              <g className="animate-candle-flame">
                <ellipse cx="140" cy="76" rx="5" ry="9" fill="#55B7E8" />
                <ellipse cx="140" cy="77" rx="3" ry="6" fill="#D9F2FF" />
                <circle cx="140" cy="78" r="1.5" fill="#FFFFFF" />
              </g>

              {/* Flame 2 (Center) */}
              <g className="animate-candle-flame" style={{ animationDelay: "0.4s" }}>
                <ellipse cx="160" cy="67" rx="6" ry="10" fill="#55B7E8" />
                <ellipse cx="160" cy="68" rx="3.5" ry="7" fill="#D9F2FF" />
                <circle cx="160" cy="69" r="2" fill="#FFFFFF" />
              </g>

              {/* Flame 3 */}
              <g className="animate-candle-flame" style={{ animationDelay: "0.8s" }}>
                <ellipse cx="180" cy="76" rx="5" ry="9" fill="#55B7E8" />
                <ellipse cx="180" cy="77" rx="3" ry="6" fill="#D9F2FF" />
                <circle cx="180" cy="78" r="1.5" fill="#FFFFFF" />
              </g>
            </g>
          )}

          {/* Wisps of smoke when blown out */}
          {!candlesLit && (
            <g opacity="0.7">
              <path
                d="M140 85 Q136 75 142 65"
                stroke="#55B7E8"
                strokeWidth="1.5"
                strokeDasharray="2 2"
                fill="none"
              />
              <path
                d="M160 76 Q165 65 158 55"
                stroke="#55B7E8"
                strokeWidth="2"
                strokeDasharray="3 2"
                fill="none"
              />
              <path
                d="M180 85 Q184 75 178 65"
                stroke="#55B7E8"
                strokeWidth="1.5"
                strokeDasharray="2 2"
                fill="none"
              />
            </g>
          )}

          {/* Definitions */}
          <defs>
            <linearGradient id="standGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#55B7E8" />
              <stop offset="50%" stopColor="#1769AA" />
              <stop offset="100%" stopColor="#071A33" />
            </linearGradient>
            <linearGradient id="candleGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#F4FAFF" />
              <stop offset="100%" stopColor="#55B7E8" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {/* Interactive Controls & Countdown Area */}
      <div className="mt-4 flex flex-col items-center text-center min-h-[120px] justify-center">
        {phase === "idle" && (
          <button
            type="button"
            onClick={handleStartCountdown}
            className="group inline-flex items-center gap-3 px-9 py-4 bg-gradient-to-r from-[#1769AA] via-[#55B7E8] to-[#1769AA] text-[#071A33] rounded-full font-bold text-sm sm:text-base tracking-widest uppercase transition-all duration-300 shadow-[0_10px_30px_rgba(85,183,232,0.4)] hover:shadow-[0_15px_45px_rgba(85,183,232,0.7)] hover:scale-105 active:scale-95 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#55B7E8]"
          >
            <Sparkles className="w-5 h-5 text-[#071A33] group-hover:rotate-12 transition-transform" />
            <span>LET THE CELEBRATION BEGIN</span>
          </button>
        )}

        {phase === "counting" && (
          <div className="flex flex-col items-center">
            <span
              ref={countdownElRef}
              className="font-serif text-7xl sm:text-8xl font-bold text-transparent bg-clip-text bg-gradient-to-b from-[#F4FAFF] via-[#D9F2FF] to-[#55B7E8] tracking-wider drop-shadow-[0_4px_25px_rgba(85,183,232,0.6)]"
            >
              {countdown}
            </span>
            <p className="font-serif italic text-sm sm:text-base text-[#D9F2FF]/80 mt-1">
              Gather your warmest thoughts, Maa...
            </p>
          </div>
        )}

        {phase === "ready-to-wish" && (
          <div className="flex flex-col items-center space-y-4 animate-fade-in">
            <p className="font-serif italic text-lg sm:text-xl text-[#F4FAFF]">
              Close your eyes, make a heartfelt wish in your heart...
            </p>
            <div className="flex items-center gap-4">
              <button
                type="button"
                onClick={handleBlowCandles}
                className="inline-flex items-center gap-2.5 px-8 py-3.5 bg-[#F4FAFF] text-[#071A33] hover:bg-[#D9F2FF] rounded-full font-bold text-sm tracking-widest uppercase transition-all duration-300 shadow-[0_10px_30px_rgba(85,183,232,0.6)] hover:scale-105 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#55B7E8]"
              >
                <Wind className="w-4 h-4 text-[#071A33]" />
                <span>MAKE YOUR WISH</span>
              </button>

              <button
                type="button"
                onClick={handleReset}
                aria-label="Restart countdown"
                className="p-3 rounded-full bg-[#123B70]/80 text-[#D9F2FF] hover:text-[#F4FAFF] border border-[#55B7E8]/30 transition-all cursor-pointer"
                title="Restart countdown"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {phase === "blown-out" && (
          <div className="flex flex-col items-center animate-fade-in">
            <Sparkles className="w-7 h-7 text-[#55B7E8] animate-spin mb-2" />
            <p className="font-serif italic text-xl text-[#55B7E8] drop-shadow-md">
              Your wish is rising to heaven...
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
