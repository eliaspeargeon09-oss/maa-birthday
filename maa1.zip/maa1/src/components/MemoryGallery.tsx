import React, { useState, useEffect, useRef } from "react";
import { memories, MemoryItem } from "../data/memories";
import { MemoryLightbox } from "./MemoryLightbox";
import { Sparkles, Image as ImageIcon } from "lucide-react";
import anime from "animejs";

export const MemoryGallery: React.FC = () => {
  const [selectedMemoryIndex, setSelectedMemoryIndex] = useState<number | null>(null);
  const galleryGridRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (galleryGridRef.current) {
      const cards = galleryGridRef.current.querySelectorAll(".gallery-card");
      anime({
        targets: cards,
        opacity: [0, 1],
        translateY: [25, 0],
        scale: [0.96, 1],
        delay: anime.stagger(120),
        duration: 850,
        easing: "easeOutCubic"
      });
    }
  }, []);

  const handleOpen = (index: number) => {
    setSelectedMemoryIndex(index);
  };

  const handleClose = () => {
    setSelectedMemoryIndex(null);
  };

  const handlePrev = () => {
    if (selectedMemoryIndex === null) return;
    setSelectedMemoryIndex((selectedMemoryIndex - 1 + memories.length) % memories.length);
  };

  const handleNext = () => {
    if (selectedMemoryIndex === null) return;
    setSelectedMemoryIndex((selectedMemoryIndex + 1) % memories.length);
  };

  return (
    <div className="w-full">
      {/* 2 or 3-column Floating Gallery Grid */}
      <div ref={galleryGridRef} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
        {memories.map((item: MemoryItem, idx: number) => {
          return (
            <div
              key={item.id}
              role="button"
              tabIndex={0}
              aria-label={`View memory: ${item.caption}`}
              onClick={() => handleOpen(idx)}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  handleOpen(idx);
                }
              }}
              className="gallery-card opacity-0 group relative glass-water-card p-4 sm:p-5 rounded-2xl transition-all duration-500 cursor-pointer hover:-translate-y-2 hover:shadow-[0_20px_45px_rgba(85,183,232,0.25)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#55B7E8]"
            >
              {/* Photo Frame with Water Reflection Highlight */}
              <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-[#071A33]/80 border border-[#55B7E8]/20 mb-4 shadow-inner">
                <img
                  src={item.image}
                  alt={item.caption}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  onError={(e) => {
                    const target = e.currentTarget;
                    target.style.display = "none";
                    const fallback = target.parentElement?.querySelector(".gallery-fallback");
                    if (fallback) {
                      (fallback as HTMLElement).style.display = "flex";
                    }
                  }}
                />

                {/* Graceful fallback archival keepsake mat */}
                <div className="gallery-fallback hidden absolute inset-0 flex flex-col items-center justify-center p-5 text-center bg-gradient-to-br from-[#123B70] via-[#071A33] to-[#1769AA]/80">
                  <div className="w-12 h-12 rounded-full border border-[#55B7E8]/60 flex items-center justify-center text-[#55B7E8] bg-[#071A33]/60 mb-3 shadow-[0_0_15px_rgba(85,183,232,0.3)]">
                    <ImageIcon className="w-6 h-6 text-[#55B7E8]" />
                  </div>
                  <h5 className="font-serif font-semibold text-base text-[#F4FAFF] leading-tight">
                    {item.placeholderTitle}
                  </h5>
                  <p className="font-serif italic text-xs text-[#D9F2FF]/70 mt-1 line-clamp-2">
                    A precious memory held in our hearts
                  </p>
                </div>

                {/* Hover overlay hint */}
                <div className="absolute inset-0 bg-[#071A33]/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-xs">
                  <span className="px-4 py-1.5 bg-[#55B7E8] text-[#071A33] text-xs font-semibold rounded-full shadow-lg tracking-wider uppercase">
                    Click to view
                  </span>
                </div>
              </div>

              {/* Caption & Details */}
              <div className="pt-1">
                {item.subheading && (
                  <span className="block text-[11px] font-sans uppercase tracking-wider text-[#55B7E8]/80 mb-1">
                    {item.subheading}
                  </span>
                )}
                <p className="font-serif text-[#F4FAFF] text-lg leading-snug group-hover:text-[#55B7E8] transition-colors">
                  "{item.caption}"
                </p>
              </div>

              {/* Water droplet corner highlight */}
              <div
                className="absolute top-3 right-3 w-2.5 h-2.5 rounded-full bg-[#55B7E8]/40 group-hover:bg-[#55B7E8] group-hover:shadow-[0_0_8px_#55B7E8] transition-all"
                aria-hidden="true"
              />
            </div>
          );
        })}
      </div>

      {/* Footer Info Ribbon */}
      <div className="mt-12 pt-8 border-t border-[#55B7E8]/20 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
        <div className="flex items-center gap-2 text-xs font-serif italic text-[#D9F2FF]/80">
          <Sparkles className="w-4 h-4 text-[#55B7E8]" />
          <span>Click any photograph to view in full resolution</span>
        </div>
        <div className="text-xs font-sans text-[#B8D8EA]/60">
          Photographs configurable in <code className="text-[#55B7E8] font-mono">/public/images/</code>
        </div>
      </div>

      {/* Lightbox Component */}
      <MemoryLightbox
        isOpen={selectedMemoryIndex !== null}
        memory={selectedMemoryIndex !== null ? memories[selectedMemoryIndex] : null}
        currentIndex={selectedMemoryIndex ?? 0}
        totalMemories={memories.length}
        onClose={handleClose}
        onPrev={handlePrev}
        onNext={handleNext}
      />
    </div>
  );
};
