import React from "react";
import { ChevronLeft, ChevronRight, RotateCcw } from "lucide-react";

interface ChapterNavigationProps {
  currentChapter: number;
  totalChapters: number;
  canGoBack?: boolean;
  canGoNext?: boolean;
  nextLabel?: string;
  backLabel?: string;
  onBack: () => void;
  onNext: () => void;
  onRestart?: () => void;
  isDarkTheme?: boolean;
  isBusy?: boolean;
}

export const ChapterNavigation: React.FC<ChapterNavigationProps> = ({
  currentChapter,
  totalChapters,
  canGoBack = true,
  canGoNext = true,
  nextLabel = "Continue",
  backLabel = "Back",
  onBack,
  onNext,
  onRestart,
  isBusy = false
}) => {
  const isFirst = currentChapter === 1;
  const isLast = currentChapter === totalChapters;

  return (
    <footer className="fixed bottom-0 left-0 right-0 z-40 px-4 sm:px-8 py-3.5 transition-colors duration-500 backdrop-blur-md border-t bg-[#071A33]/85 border-[#55B7E8]/20 text-[#F4FAFF]">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
        {/* Back / Restart Action */}
        <div>
          {!isFirst ? (
            <button
              type="button"
              onClick={onBack}
              disabled={!canGoBack || isBusy}
              aria-label="Go to previous chapter"
              className="flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-semibold rounded-full transition-all cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#55B7E8] text-[#D9F2FF] hover:text-[#F4FAFF] hover:bg-[#123B70]/60 active:bg-[#1769AA]/40 disabled:opacity-30 disabled:pointer-events-none"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>{backLabel}</span>
            </button>
          ) : (
            <span className="text-xs italic opacity-50 font-serif text-[#D9F2FF]">
              A cinematic journey for Maa
            </span>
          )}
        </div>

        {/* Center reading reminder */}
        <div className="hidden md:flex items-center gap-2 text-xs opacity-70 font-serif italic text-[#D9F2FF]">
          <span>Take your time · Read & reflect at your own pace</span>
        </div>

        {/* Continue / Next / Restart Action */}
        <div className="flex items-center gap-2.5">
          {isLast && onRestart && (
            <button
              type="button"
              onClick={onRestart}
              className="flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-semibold rounded-full transition-all cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#55B7E8] text-[#55B7E8] hover:bg-[#123B70]/60 border border-[#55B7E8]/30"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Start Over</span>
            </button>
          )}

          {!isLast && (
            <button
              type="button"
              onClick={onNext}
              disabled={!canGoNext || isBusy}
              aria-label="Continue to next chapter"
              className="group flex items-center gap-2 px-6 py-2.5 text-xs sm:text-sm font-semibold rounded-full transition-all duration-300 shadow-[0_4px_20px_rgba(85,183,232,0.35)] cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#55B7E8] bg-gradient-to-r from-[#1769AA] via-[#55B7E8] to-[#1769AA] text-[#071A33] hover:shadow-[0_8px_25px_rgba(85,183,232,0.6)] hover:scale-105 active:scale-95 disabled:opacity-40 disabled:pointer-events-none"
            >
              <span>{nextLabel}</span>
              <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>
          )}
        </div>
      </div>
    </footer>
  );
};
