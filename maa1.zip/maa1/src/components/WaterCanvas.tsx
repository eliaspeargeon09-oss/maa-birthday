import React, { useEffect, useRef, useCallback } from "react";

interface Ripple {
  x: number; // 0..1 normalized
  y: number; // 0..1 normalized
  startTime: number; // seconds
  intensity: number; // 0..1
}

interface WaterCanvasProps {
  intensity?: "calm" | "medium" | "luminous";
  theme?: "ocean" | "sapphire" | "midnight";
  className?: string;
  onWaterReady?: () => void;
}

const MAX_RIPPLES = 20;

export const WaterCanvas: React.FC<WaterCanvasProps> = ({
  intensity = "medium",
  theme = "ocean",
  className = ""
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const ripplesRef = useRef<Ripple[]>([]);
  const lastPointerPos = useRef<{ x: number; y: number; time: number }>({ x: 0, y: 0, time: 0 });
  const isWebGlSupported = useRef<boolean>(true);
  const animFrameId = useRef<number | null>(null);

  // Expose ripple adder to window event so buttons can dispatch ripples
  const addRipple = useCallback((normX: number, normY: number, power: number = 0.8) => {
    const now = performance.now() / 1000;
    const ripples = ripplesRef.current;
    
    // Replace oldest or dead ripple
    if (ripples.length >= MAX_RIPPLES) {
      ripples.shift();
    }
    ripples.push({
      x: normX,
      y: normY,
      startTime: now,
      intensity: Math.min(1.5, Math.max(0.2, power))
    });
  }, []);

  useEffect(() => {
    const handleGlobalRipple = (e: CustomEvent<{ x: number; y: number; power?: number }>) => {
      if (e.detail) {
        const rect = canvasRef.current?.getBoundingClientRect();
        if (rect) {
          const normX = (e.detail.x - rect.left) / rect.width;
          const normY = 1.0 - (e.detail.y - rect.top) / rect.height; // invert for WebGL UV
          addRipple(normX, normY, e.detail.power || 1.0);
        }
      }
    };

    window.addEventListener("trigger-water-ripple" as any, handleGlobalRipple as any);
    return () => {
      window.removeEventListener("trigger-water-ripple" as any, handleGlobalRipple as any);
    };
  }, [addRipple]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    let gl: WebGLRenderingContext | null = null;
    let program: WebGLProgram | null = null;
    let positionBuffer: WebGLBuffer | null = null;

    // Check prefers-reduced-motion
    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    // Attempt WebGL context initialization
    try {
      gl = (canvas.getContext("webgl", { alpha: false, antialias: false, powerPreference: "high-performance" }) ||
            canvas.getContext("experimental-webgl")) as WebGLRenderingContext | null;
    } catch {
      gl = null;
    }

    if (!gl) {
      isWebGlSupported.current = false;
    }

    let isRunning = true;
    let startTime = performance.now();

    // -------------------------------------------------------------
    // WebGL Shader Setup
    // -------------------------------------------------------------
    if (gl) {
      const vsSource = `
        attribute vec2 a_position;
        varying vec2 v_uv;
        void main() {
          v_uv = (a_position + 1.0) * 0.5;
          gl_Position = vec4(a_position, 0.0, 1.0);
        }
      `;

      const fsSource = `
        precision highp float;
        varying vec2 v_uv;
        uniform vec2 u_resolution;
        uniform float u_time;
        uniform float u_intensity;
        uniform vec4 u_ripples[${MAX_RIPPLES}];
        uniform int u_ripple_count;

        // Procedural caustics function
        float caustic(vec2 p, float t) {
          vec2 p1 = p * 4.5 + vec2(sin(t * 0.35 + p.y * 1.5), cos(t * 0.4 + p.x * 1.5)) * 0.35;
          float c1 = sin(p1.x + sin(p1.y + t * 0.7));
          float c2 = cos(p1.y + cos(p1.x - t * 0.6));
          float c3 = sin((p1.x + p1.y) * 1.4 + t * 0.85);
          return pow((c1 + c2 + c3 + 3.0) / 6.0, 4.0);
        }

        // Secondary deeper wave
        float waveCaustic(vec2 p, float t) {
          vec2 p2 = p * 8.0 + vec2(t * 0.2, -t * 0.15);
          float w = sin(p2.x * 0.8 + cos(p2.y * 0.6 + t * 0.5));
          return pow(max(0.0, (w + 1.0) * 0.5), 3.0);
        }

        void main() {
          vec2 uv = v_uv;
          float aspect = u_resolution.x / u_resolution.y;
          vec2 aspectUv = vec2(uv.x * aspect, uv.y);

          // Calculate displacement from cursor ripples
          vec2 displacement = vec2(0.0);
          float totalHighlight = 0.0;

          for (int i = 0; i < ${MAX_RIPPLES}; i++) {
            if (i >= u_ripple_count) break;
            vec4 rip = u_ripples[i];
            vec2 ripPos = vec2(rip.x * aspect, rip.y);
            float age = u_time - rip.z;

            if (age > 0.0 && age < 3.2) {
              float d = distance(aspectUv, ripPos);
              float waveSpeed = 1.6;
              float waveRadius = age * waveSpeed;
              float distFromWave = abs(d - waveRadius);

              // Wave packet profile
              if (distFromWave < 0.35) {
                float attenuation = exp(-age * 1.1) * exp(-d * 1.2) * rip.w;
                float wave = sin((d - waveRadius) * 45.0) * attenuation;
                
                // Normal direction away from ripple center
                vec2 dir = normalize(aspectUv - ripPos + vec2(0.0001));
                displacement += dir * wave * 0.045;
                totalHighlight += max(0.0, wave) * attenuation * 1.8;
              }
            }
          }

          vec2 distortedUv = uv + displacement;

          // Water base gradient
          // Ocean deep: #071A33 (vec3(0.027, 0.102, 0.200))
          // Ocean primary: #123B70 (vec3(0.071, 0.231, 0.439))
          // Liquid sapphire: #1769AA (vec3(0.090, 0.412, 0.667))
          // Bright water blue: #55B7E8 (vec3(0.333, 0.718, 0.910))
          vec3 deepMidnight = vec3(0.027, 0.102, 0.200);
          vec3 primaryOcean = vec3(0.071, 0.231, 0.439);
          vec3 sapphire = vec3(0.090, 0.412, 0.667);
          vec3 brightWater = vec3(0.333, 0.718, 0.910);
          vec3 paleHighlight = vec3(0.851, 0.949, 1.0);

          // Diagonal gradient across the water plane
          float gradT = clamp((distortedUv.x * 0.4 + distortedUv.y * 0.6), 0.0, 1.0);
          vec3 baseWater = mix(deepMidnight, primaryOcean, smoothstep(0.0, 0.5, gradT));
          baseWater = mix(baseWater, sapphire, smoothstep(0.45, 0.9, gradT));

          // Atmospheric light ray passing through water
          float lightRay = sin(distortedUv.x * 3.0 - distortedUv.y * 2.0 + u_time * 0.3) * 0.5 + 0.5;
          lightRay = pow(lightRay, 3.5) * 0.18;
          baseWater += brightWater * lightRay;

          // Moving refractive caustics
          float caust1 = caustic(distortedUv, u_time);
          float caust2 = waveCaustic(distortedUv, u_time);
          float combinedCaustic = (caust1 * 0.65 + caust2 * 0.35) * u_intensity;

          // Blend caustics into water
          vec3 waterColor = baseWater + brightWater * (combinedCaustic * 0.45) + paleHighlight * (combinedCaustic * 0.22);

          // Add ripple specular highlights
          waterColor += paleHighlight * (totalHighlight * 0.6);
          waterColor += brightWater * (totalHighlight * 0.4);

          // Subtle vignette towards screen corners
          float vignette = 1.0 - length((uv - 0.5) * 1.15) * 0.35;
          waterColor *= clamp(vignette, 0.75, 1.0);

          gl_FragColor = vec4(waterColor, 1.0);
        }
      `;

      const createShader = (type: number, source: string) => {
        if (!gl) return null;
        const shader = gl.createShader(type);
        if (!shader) return null;
        gl.shaderSource(shader, source);
        gl.compileShader(shader);
        if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
          console.warn("Shader compile error:", gl.getShaderInfoLog(shader));
          gl.deleteShader(shader);
          return null;
        }
        return shader;
      };

      const vs = createShader(gl.VERTEX_SHADER, vsSource);
      const fs = createShader(gl.FRAGMENT_SHADER, fsSource);

      if (vs && fs) {
        program = gl.createProgram();
        if (program) {
          gl.attachShader(program, vs);
          gl.attachShader(program, fs);
          gl.linkProgram(program);

          if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
            console.warn("Program link error:", gl.getProgramInfoLog(program));
            program = null;
          }
        }
      }

      if (program) {
        positionBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
        // Full screen quad (-1 to 1)
        const positions = new Float32Array([
          -1, -1,
           1, -1,
          -1,  1,
          -1,  1,
           1, -1,
           1,  1
        ]);
        gl.bufferData(gl.ARRAY_BUFFER, positions, gl.STATIC_DRAW);
      } else {
        isWebGlSupported.current = false;
      }
    }

    // -------------------------------------------------------------
    // Resize Handler
    // -------------------------------------------------------------
    const resize = () => {
      if (!canvas) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 1.75); // clamp for optimal frame rates
      const displayWidth = window.innerWidth;
      const displayHeight = window.innerHeight;

      if (canvas.width !== Math.floor(displayWidth * dpr) || canvas.height !== Math.floor(displayHeight * dpr)) {
        canvas.width = Math.floor(displayWidth * dpr);
        canvas.height = Math.floor(displayHeight * dpr);
        canvas.style.width = `${displayWidth}px`;
        canvas.style.height = `${displayHeight}px`;

        if (gl) {
          gl.viewport(0, 0, canvas.width, canvas.height);
        }
      }
    };

    window.addEventListener("resize", resize);
    resize();

    // -------------------------------------------------------------
    // Mouse & Touch Interaction Listeners
    // -------------------------------------------------------------
    const handlePointerMove = (e: MouseEvent | TouchEvent) => {
      const now = performance.now();
      // Throttle ripple emission (every ~35ms)
      if (now - lastPointerPos.current.time < 35) return;

      let clientX = 0;
      let clientY = 0;

      if ("touches" in e) {
        if (e.touches.length > 0) {
          clientX = e.touches[0].clientX;
          clientY = e.touches[0].clientY;
        } else return;
      } else {
        clientX = e.clientX;
        clientY = e.clientY;
      }

      const dx = clientX - lastPointerPos.current.x;
      const dy = clientY - lastPointerPos.current.y;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Only emit if pointer moved at least 6px
      if (dist > 6) {
        const normX = clientX / window.innerWidth;
        const normY = 1.0 - clientY / window.innerHeight; // WebGL UV Y is bottom-to-top
        const speedFactor = Math.min(dist / 20, 1.4);
        addRipple(normX, normY, 0.45 + speedFactor * 0.4);

        lastPointerPos.current = { x: clientX, y: clientY, time: now };
      }
    };

    const handlePointerDown = (e: MouseEvent | TouchEvent) => {
      let clientX = 0;
      let clientY = 0;
      if ("touches" in e) {
        if (e.touches.length > 0) {
          clientX = e.touches[0].clientX;
          clientY = e.touches[0].clientY;
        } else return;
      } else {
        clientX = e.clientX;
        clientY = e.clientY;
      }

      const normX = clientX / window.innerWidth;
      const normY = 1.0 - clientY / window.innerHeight;
      addRipple(normX, normY, 1.1); // Stronger ripple on click/tap
      lastPointerPos.current = { x: clientX, y: clientY, time: performance.now() };
    };

    window.addEventListener("mousemove", handlePointerMove, { passive: true });
    window.addEventListener("mousedown", handlePointerDown, { passive: true });
    window.addEventListener("touchmove", handlePointerMove, { passive: true });
    window.addEventListener("touchstart", handlePointerDown, { passive: true });

    // Handle tab visibility to save power & avoid large dt jumps
    const handleVisibilityChange = () => {
      if (document.hidden) {
        isRunning = false;
      } else {
        isRunning = true;
        startTime = performance.now();
        loop();
      }
    };
    document.addEventListener("visibilitychange", handleVisibilityChange);

    // -------------------------------------------------------------
    // Main Render Loop
    // -------------------------------------------------------------
    const uIntensityVal = intensity === "calm" ? 0.45 : intensity === "luminous" ? 0.95 : 0.7;

    const loop = () => {
      if (!isRunning) return;

      const elapsed = (performance.now() - startTime) / 1000;
      const animTime = prefersReducedMotion ? 0.5 : elapsed;

      // Filter out ripples older than 3.5s
      const nowSec = performance.now() / 1000;
      ripplesRef.current = ripplesRef.current.filter((r) => nowSec - r.startTime < 3.5);

      if (gl && program && positionBuffer) {
        gl.useProgram(program);

        // Uniforms
        const uRes = gl.getUniformLocation(program, "u_resolution");
        const uTime = gl.getUniformLocation(program, "u_time");
        const uInt = gl.getUniformLocation(program, "u_intensity");
        const uRipCount = gl.getUniformLocation(program, "u_ripple_count");

        gl.uniform2f(uRes, canvas.width, canvas.height);
        gl.uniform1f(uTime, animTime);
        gl.uniform1f(uInt, uIntensityVal);
        gl.uniform1i(uRipCount, ripplesRef.current.length);

        // Send ripple array
        for (let i = 0; i < MAX_RIPPLES; i++) {
          const loc = gl.getUniformLocation(program, `u_ripples[${i}]`);
          if (i < ripplesRef.current.length) {
            const r = ripplesRef.current[i];
            gl.uniform4f(loc, r.x, r.y, r.startTime, r.intensity);
          } else {
            gl.uniform4f(loc, 0.0, 0.0, -100.0, 0.0);
          }
        }

        const aPos = gl.getAttribLocation(program, "a_position");
        gl.enableVertexAttribArray(aPos);
        gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
        gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);

        gl.drawArrays(gl.TRIANGLES, 0, 6);
      } else {
        // ---------------------------------------------------------
        // 2D Canvas Graceful Fallback
        // ---------------------------------------------------------
        const ctx = canvas.getContext("2d");
        if (ctx) {
          const w = canvas.width;
          const h = canvas.height;

          // Base gradient
          const grad = ctx.createLinearGradient(0, 0, w, h);
          grad.addColorStop(0, "#071A33");
          grad.addColorStop(0.4, "#123B70");
          grad.addColorStop(0.75, "#1769AA");
          grad.addColorStop(1, "#55B7E8");

          ctx.fillStyle = grad;
          ctx.fillRect(0, 0, w, h);

          // Procedural caustic waves using 2D paths
          ctx.save();
          ctx.globalAlpha = 0.18;
          ctx.fillStyle = "#D9F2FF";
          for (let i = 0; i < 4; i++) {
            ctx.beginPath();
            const phase = animTime * 0.8 + i * 1.5;
            for (let x = 0; x <= w; x += 30) {
              const y = h * (0.2 + i * 0.2) + Math.sin(x * 0.005 + phase) * 35;
              if (x === 0) ctx.moveTo(x, y);
              else ctx.lineTo(x, y);
            }
            ctx.lineTo(w, h);
            ctx.lineTo(0, h);
            ctx.closePath();
            ctx.fill();
          }
          ctx.restore();

          // Draw active ripples
          for (const rip of ripplesRef.current) {
            const age = nowSec - rip.startTime;
            if (age > 0 && age < 3.0) {
              const rx = rip.x * w;
              const ry = (1.0 - rip.y) * h;
              const radius = age * (w * 0.35);
              const alpha = Math.max(0, (1 - age / 3.0) * rip.intensity * 0.45);

              ctx.save();
              ctx.strokeStyle = `rgba(184, 216, 234, ${alpha})`;
              ctx.lineWidth = 3.5;
              ctx.beginPath();
              ctx.arc(rx, ry, radius, 0, Math.PI * 2);
              ctx.stroke();

              // Inner echo ring
              if (radius > 15) {
                ctx.strokeStyle = `rgba(217, 242, 255, ${alpha * 0.6})`;
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.arc(rx, ry, radius * 0.7, 0, Math.PI * 2);
                ctx.stroke();
              }
              ctx.restore();
            }
          }
        }
      }

      animFrameId.current = requestAnimationFrame(loop);
    };

    // Initial ripple to welcome the user
    setTimeout(() => {
      addRipple(0.5, 0.5, 0.9);
    }, 400);

    loop();

    return () => {
      isRunning = false;
      if (animFrameId.current) cancelAnimationFrame(animFrameId.current);
      window.removeEventListener("resize", resize);
      window.removeEventListener("mousemove", handlePointerMove);
      window.removeEventListener("mousedown", handlePointerDown);
      window.removeEventListener("touchmove", handlePointerMove);
      window.removeEventListener("touchstart", handlePointerDown);
      document.removeEventListener("visibilitychange", handleVisibilityChange);

      if (gl) {
        if (positionBuffer) gl.deleteBuffer(positionBuffer);
        if (program) gl.deleteProgram(program);
      }
    };
  }, [addRipple, intensity, theme]);

  return (
    <canvas
      ref={canvasRef}
      className={`fixed inset-0 w-full h-full pointer-events-none z-0 ${className}`}
      aria-hidden="true"
    />
  );
};

/**
 * Global helper to trigger a ripple at client coordinates (e.g. from buttons or gestures)
 */
export const triggerWaterRipple = (clientX: number, clientY: number, power: number = 1.0) => {
  const event = new CustomEvent("trigger-water-ripple", {
    detail: { x: clientX, y: clientY, power }
  });
  window.dispatchEvent(event);
};
