import React, { useState, useEffect } from "react";
import { Volume2, VolumeX } from "lucide-react";
import { musicManager } from "../utils/audioController";

export const MusicControl: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    setIsPlaying(musicManager.getIsPlaying());
    const unsubscribe = musicManager.subscribe((playing) => {
      setIsPlaying(playing);
    });
    return () => {
      unsubscribe();
    };
  }, []);

  const handleToggle = () => {
    musicManager.toggle();
  };

  return (
    <div className="relative group">
      <button
        onClick={handleToggle}
        aria-label={isPlaying ? "Mute soundtrack" : "Play soothing ocean melody"}
        className={`flex items-center gap-2.5 px-3 py-1.5 rounded-full text-xs transition-all duration-300 backdrop-blur-md border ${
          isPlaying
            ? "bg-[#1769AA]/40 border-[#55B7E8]/60 text-[#55B7E8] shadow-[0_0_15px_rgba(85,183,232,0.3)]"
            : "bg-[#071A33]/70 border-[#55B7E8]/30 text-[#D9F2FF]/70 hover:text-[#F4FAFF] hover:border-[#55B7E8]/60"
        } focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#55B7E8] cursor-pointer`}
      >
        {isPlaying ? (
          <>
            <Volume2 className="w-3.5 h-3.5 text-[#55B7E8]" />
            <span className="hidden sm:inline font-serif italic text-xs tracking-wide text-[#F4FAFF]">
              Melody playing
            </span>
            <div className="flex items-end gap-0.5 h-2.5" aria-hidden="true">
              <span className="w-0.5 h-1.5 bg-[#55B7E8] animate-pulse rounded-full" />
              <span className="w-0.5 h-2.5 bg-[#55B7E8] animate-pulse rounded-full delay-100" />
              <span className="w-0.5 h-2 bg-[#55B7E8] animate-pulse rounded-full delay-200" />
            </div>
          </>
        ) : (
          <>
            <VolumeX className="w-3.5 h-3.5 text-[#D9F2FF]/60" />
            <span className="hidden sm:inline font-serif italic text-xs tracking-wide text-[#D9F2FF]/70">
              Music muted
            </span>
          </>
        )}
      </button>

      {/* Discreet tooltip on hover */}
      <div className="absolute right-0 top-full mt-2 hidden group-hover:block pointer-events-none z-50 whitespace-nowrap text-[11px] font-sans px-2.5 py-1 rounded bg-[#071A33]/95 text-[#D9F2FF] border border-[#55B7E8]/30 shadow-lg">
        {isPlaying ? "Pause melody" : "Play soothing ambient melody"}
      </div>
    </div>
  );
};
