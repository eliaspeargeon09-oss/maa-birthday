import React, { useEffect } from "react";
import { X, ChevronLeft, ChevronRight, Heart } from "lucide-react";
import { MemoryItem } from "../data/memories";

interface MemoryLightboxProps {
  memory: MemoryItem | null;
  currentIndex: number;
  totalMemories: number;
  isOpen: boolean;
  onClose: () => void;
  onPrev: () => void;
  onNext: () => void;
}

export const MemoryLightbox: React.FC<MemoryLightboxProps> = ({
  memory,
  currentIndex,
  totalMemories,
  isOpen,
  onClose,
  onPrev,
  onNext
}) => {
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft") onPrev();
      if (e.key === "ArrowRight") onNext();
    };

    window.addEventListener("keydown", handleKeyDown);
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = originalOverflow;
    };
  }, [isOpen, onClose, onPrev, onNext]);

  if (!isOpen || !memory) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="lightbox-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 md:p-10 bg-[#071A33]/92 backdrop-blur-lg animate-fade-in"
      onClick={onClose}
    >
      <div
        className="relative max-w-4xl w-full bg-[#123B70]/90 text-[#F4FAFF] rounded-2xl sm:rounded-3xl overflow-hidden shadow-[0_25px_60px_rgba(7,26,51,0.95)] border border-[#55B7E8]/40"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top bar with count & close */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#55B7E8]/20 bg-[#071A33]/80">
          <span className="font-serif tracking-widest text-xs uppercase text-[#55B7E8]">
            Memory {currentIndex + 1} of {totalMemories}
          </span>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close image lightbox"
            className="p-1.5 rounded-full text-[#F4FAFF]/70 hover:text-[#F4FAFF] hover:bg-[#55B7E8]/20 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#55B7E8]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Image / Fallback Container */}
        <div className="relative aspect-[4/3] sm:aspect-[16/10] bg-[#071A33] flex items-center justify-center overflow-hidden">
          <img
            src={memory.image}
            alt={memory.caption}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
            onError={(e) => {
              const target = e.currentTarget;
              target.style.display = "none";
              const fallback = target.parentElement?.querySelector(".fallback-card");
              if (fallback) {
                (fallback as HTMLElement).style.display = "flex";
              }
            }}
          />

          {/* Graceful archival keepsake fallback frame */}
          <div className="fallback-card hidden absolute inset-0 flex flex-col items-center justify-center p-8 text-center bg-gradient-to-br from-[#123B70] via-[#071A33] to-[#1769AA]">
            <div className="w-16 h-16 rounded-full border-2 border-[#55B7E8] flex items-center justify-center mb-4 text-[#55B7E8] bg-[#071A33]/70 shadow-[0_0_20px_rgba(85,183,232,0.4)]">
              <Heart className="w-7 h-7 text-[#55B7E8] fill-[#55B7E8]/20" />
            </div>
            <h4 className="font-serif text-2xl text-[#F4FAFF] mb-2 font-semibold">
              {memory.placeholderTitle}
            </h4>
            <p className="font-serif italic text-sm text-[#D9F2FF]/80 max-w-md">
              A photograph of love, laughter, and timeless warmth
            </p>
            <span className="mt-4 text-[11px] font-sans tracking-wider uppercase text-[#55B7E8]/70">
              Personal photograph slot ({memory.image.replace("/images/", "")})
            </span>
          </div>

          {/* Navigation overlay controls */}
          <button
            type="button"
            onClick={onPrev}
            aria-label="Previous photograph"
            className="absolute left-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-[#071A33]/75 text-[#F4FAFF] hover:bg-[#1769AA] border border-[#55B7E8]/30 backdrop-blur-md transition-all cursor-pointer shadow-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#55B7E8]"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            type="button"
            onClick={onNext}
            aria-label="Next photograph"
            className="absolute right-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-[#071A33]/75 text-[#F4FAFF] hover:bg-[#1769AA] border border-[#55B7E8]/30 backdrop-blur-md transition-all cursor-pointer shadow-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#55B7E8]"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>

        {/* Caption and details footer */}
        <div className="p-6 sm:p-7 bg-[#071A33]/90 border-t border-[#55B7E8]/20">
          {memory.subheading && (
            <p className="font-sans text-xs tracking-wider uppercase text-[#55B7E8] mb-1">
              {memory.subheading}
            </p>
          )}
          <h3
            id="lightbox-title"
            className="font-serif text-xl sm:text-2xl text-[#F4FAFF] font-medium leading-relaxed"
          >
            "{memory.caption}"
          </h3>
        </div>
      </div>
    </div>
  );
};
