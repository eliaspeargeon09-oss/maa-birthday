import React, { useEffect, useRef } from "react";
import { birthdayContent } from "../data/birthdayContent";
import { BookOpen } from "lucide-react";
import anime from "animejs";

export const PrayerSection: React.FC = () => {
  const { chapterSix } = birthdayContent;
  const containerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (containerRef.current) {
      const items = containerRef.current.querySelectorAll(".prayer-line");
      anime({
        targets: items,
        opacity: [0, 1],
        translateY: [15, 0],
        delay: anime.stagger(140),
        duration: 800,
        easing: "easeOutCubic"
      });
    }
  }, []);

  return (
    <div ref={containerRef} className="w-full max-w-3xl mx-auto flex flex-col items-center select-none relative z-10">
      {/* Reverent Card Container */}
      <div className="w-full glass-water-card bg-[#071A33]/85 text-[#F4FAFF] rounded-2xl sm:rounded-3xl p-7 sm:p-12 shadow-[0_25px_60px_rgba(7,26,51,0.95)] border border-[#55B7E8]/35 relative overflow-hidden">
        {/* Soft atmospheric halo in the background */}
        <div
          className="absolute -top-24 left-1/2 -translate-x-1/2 w-96 h-96 bg-[#55B7E8]/10 rounded-full blur-3xl pointer-events-none"
          aria-hidden="true"
        />

        {/* Reverent icon */}
        <div className="flex justify-center mb-6">
          <div className="w-12 h-12 rounded-full border border-[#55B7E8]/50 bg-[#123B70]/60 flex items-center justify-center text-[#55B7E8] shadow-[0_0_20px_rgba(85,183,232,0.3)]">
            <BookOpen className="w-5 h-5 text-[#55B7E8]" />
          </div>
        </div>

        {/* Introduction */}
        <p className="prayer-line opacity-0 text-center font-serif italic text-base sm:text-xl text-[#D9F2FF] mb-8 max-w-xl mx-auto leading-relaxed">
          "{chapterSix.introduction}"
        </p>

        {/* Prayer Body */}
        <div className="space-y-4 font-serif text-[#F4FAFF] text-base sm:text-lg leading-relaxed sm:leading-loose text-left sm:text-justify max-w-2xl mx-auto">
          {chapterSix.prayer.map((line, idx) => {
            const isFirst = idx === 0;
            const isAmen = idx === chapterSix.prayer.length - 1;

            return (
              <p
                key={idx}
                className={`prayer-line opacity-0 ${
                  isFirst
                    ? "font-bold text-xl sm:text-2xl text-[#55B7E8] italic"
                    : isAmen
                    ? "font-bold text-lg sm:text-xl text-[#55B7E8] pt-2"
                    : "text-[#D9F2FF]/95"
                }`}
              >
                {line}
              </p>
            );
          })}
        </div>

        {/* Divider with subtle blessing ribbon */}
        <div className="my-10 flex items-center justify-center gap-3">
          <div className="h-px w-16 bg-[#55B7E8]/40" />
          <span className="font-serif text-[#55B7E8] text-xs uppercase tracking-widest">
            A Blessing from Scripture
          </span>
          <div className="h-px w-16 bg-[#55B7E8]/40" />
        </div>

        {/* Numbers 6:24-26 Scripture Card */}
        <div className="prayer-line opacity-0 bg-[#123B70]/60 rounded-2xl p-6 sm:p-8 border border-[#55B7E8]/30 text-center max-w-2xl mx-auto shadow-inner">
          <div className="space-y-1.5 font-serif text-lg sm:text-xl text-[#F4FAFF] leading-relaxed italic">
            {chapterSix.verse.lines.map((vLine, vIdx) => (
              <p key={vIdx}>{vLine}</p>
            ))}
          </div>
          <p className="mt-4 font-sans text-xs uppercase tracking-widest text-[#55B7E8] font-semibold">
            {chapterSix.verse.reference}
          </p>
        </div>
      </div>
    </div>
  );
};
