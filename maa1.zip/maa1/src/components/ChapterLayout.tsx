import React from "react";
import { ProgressIndicator } from "./ProgressIndicator";
import { MusicControl } from "./MusicControl";
import { LiquidBackground } from "./LiquidBackground";

interface ChapterLayoutProps {
  currentChapter: number;
  totalChapters: number;
  chapterTitles: string[];
  onSelectChapter: (index: number) => void;
  children: React.ReactNode;
}

export const ChapterLayout: React.FC<ChapterLayoutProps> = ({
  currentChapter,
  totalChapters,
  chapterTitles,
  onSelectChapter,
  children
}) => {
  return (
    <div className="relative min-h-screen flex flex-col bg-[#071A33] text-[#F4FAFF] overflow-x-hidden selection:bg-[#55B7E8]/30 selection:text-[#F4FAFF]">
      {/* Immersive Living Liquid Water Environment (WebGL Shader + Cursor Ripples + Particles) */}
      <LiquidBackground currentChapter={currentChapter} />

      {/* Top Header Navigation */}
      <header className="sticky top-0 z-40 px-4 sm:px-8 py-3.5 backdrop-blur-md border-b bg-[#071A33]/80 border-[#55B7E8]/20 text-[#F4FAFF]">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
          {/* Brand Wordmark */}
          <button
            type="button"
            onClick={() => onSelectChapter(1)}
            className="group flex items-center gap-2 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#55B7E8] rounded-md px-1"
            aria-label="Celebrating Maa - return to start"
          >
            <span className="font-serif italic text-lg sm:text-2xl font-bold tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-[#F4FAFF] via-[#D9F2FF] to-[#55B7E8] group-hover:brightness-110 transition-all">
              For Maa
            </span>
            <span className="text-[10px] font-sans uppercase tracking-widest px-2 py-0.5 rounded-full bg-[#1769AA]/40 text-[#55B7E8] border border-[#55B7E8]/30">
              Birthday
            </span>
          </button>

          {/* Chapter Progress Indicator */}
          <div className="hidden sm:block">
            <ProgressIndicator
              currentChapter={currentChapter}
              totalChapters={totalChapters}
              chapterTitles={chapterTitles}
              onSelectChapter={onSelectChapter}
            />
          </div>

          {/* Music Audio Controller */}
          <div className="flex items-center gap-2">
            <div className="sm:hidden">
              <span className="font-serif text-xs text-[#55B7E8]">
                {currentChapter}/{totalChapters}
              </span>
            </div>
            <MusicControl />
          </div>
        </div>
      </header>

      {/* Main Content Viewport */}
      <main
        role="main"
        aria-live="polite"
        className="relative z-10 flex-1 flex flex-col justify-center px-4 sm:px-6 md:px-8 py-8 sm:py-12 pb-28 max-w-7xl mx-auto w-full"
      >
        {children}
      </main>
    </div>
  );
};
